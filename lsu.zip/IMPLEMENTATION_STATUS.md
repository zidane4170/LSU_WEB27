# LSU Website — Frontend Review Package

## Frontend changes in this revision
- Corrected homepage slogan spelling from `এক্কা` to `একা`.
- Rebuilt Contact page with only Phone, Email, Facebook and LinkedIn; removed the message form.
- Added clickable phone and email links using the supplied contact details.
- Preserved the supplied LSU logo and existing favicon references.
- Homepage statistics remain limited to Established (2007), Verified members and Upcoming events.
- Homepage President preview is sourced from the verified active President member record.
- Profile social links render as View buttons; edit fields remain URL inputs.
- Initial Main Admin email is configured as `abdullahalrafi1007@gmail.com`.
- Admin Panel is not listed in global navigation.
- Added clean URL rewrites for the main pages.
- Removed the Notices promotion from the homepage; legacy source file is retained but not linked as a required page.

## Not a completed production release
The following backend workflows still require implementation and live Firebase verification:
- Multiple Main Admin / Media Admin provisioning and permission enforcement.
- Activity logs with actor email, timestamp, action and before/after values.
- Secure permanent Firebase Authentication account deletion through a trusted backend/Admin SDK, with confirmation.
- Full Events and Gallery admin CRUD, including Drive URL validation and image preview.
- Final Firestore Rules review and staging tests.

Deploy to a staging site first. Do not treat the backend items above as complete.
