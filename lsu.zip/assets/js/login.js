/* Sign In page. Never redirects on load — even when already signed in. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$;
    var params = new URLSearchParams(window.location.search);
    var next = L.safeNext(params.get('next'), '/profile');
    var slot = $('#authSlot'), navigating = false;

    function formView() {
      slot.innerHTML =
        '<img class="avatar avatar-lg" src="' + L.guestAvatar() + '" alt="" width="76" height="76">' +
        '<h2 id="loginTitle">Sign In</h2><p class="sub">Use your email or LSU Member ID.</p>' +
        '<form class="form" id="loginForm" novalidate>' +
        '<div class="alert alert-error" id="formAlert" role="alert"></div>' +
        (params.get('registered') ? '<div class="alert alert-ok show">Account created. Please sign in.</div>' : '') +
        (params.get('reset') ? '<div class="alert alert-ok show">Password updated. Please sign in.</div>' : '') +
        '<div class="field" id="fId"><label for="loginId">Email or Member ID</label><input class="input" id="loginId" name="loginId" type="text" inputmode="email" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="you@example.com"><span class="field-error" id="eId"></span></div>' +
        '<div class="field" id="fPw"><label for="loginPw">Password</label><div class="input-wrap"><input class="input" id="loginPw" name="loginPw" type="password" autocomplete="current-password" placeholder="Enter your password"><button type="button" class="input-toggle" id="pwToggle" aria-label="Show password" aria-pressed="false">' + L.icon('eye') + '</button></div><span class="field-error" id="ePw"></span></div>' +
        '<div class="form-row"><label class="check"><input type="checkbox" id="remember" checked> Keep me signed in</label><a class="text-link" href="/forgot-password">Forgot password?</a></div>' +
        '<button class="btn btn-primary btn-block" id="submitBtn" type="submit">Sign In</button>' +
        '</form>' +
        '<p class="auth-foot">New to LSU? <a class="text-link" href="/register">Create an account</a></p>';
      bindForm();
    }

    function signedInView(u) {
      slot.innerHTML =
        '<img class="avatar avatar-lg" src="' + (u.photo || L.avatar(u.name)) + '" alt="" width="76" height="76">' +
        '<h2 id="loginTitle">You’re signed in</h2>' +
        '<p class="sub">Signed in as <strong>' + L.esc(u.name) + '</strong>' + (u.verified ? ' ' + L.verifiedBadge() : '') + '</p>' +
        '<div class="form"><a class="btn btn-primary btn-block" href="' + L.esc(next) + '">Continue</a>' +
        '<button type="button" class="btn btn-outline btn-block" id="switchBtn">Sign out and use another account</button></div>';
      $('#switchBtn').addEventListener('click', function () { L.auth.logout(); });
    }

    function setErr(fieldId, errId, msg) {
      var f = $('#' + fieldId), inp = f.querySelector('input');
      f.classList.toggle('has-error', !!msg);
      $('#' + errId).textContent = msg || '';
      if (msg) inp.setAttribute('aria-invalid', 'true'); else inp.removeAttribute('aria-invalid');
      return !msg;
    }
    function validate() {
      var id = $('#loginId').value.trim(), pw = $('#loginPw').value;
      var okId = setErr('fId', 'eId', !id ? 'Enter your email or Member ID.' : (id.indexOf('@') > -1 && !L.auth.isEmail(id) ? 'Enter a valid email address.' : ''));
      var okPw = setErr('fPw', 'ePw', !pw ? 'Enter your password.' : '');
      if (!okId) $('#loginId').focus(); else if (!okPw) $('#loginPw').focus();
      return okId && okPw;
    }

    function bindForm() {
      var form = $('#loginForm'), alertBox = $('#formAlert'), btn = $('#submitBtn');
      $('#pwToggle').addEventListener('click', function (e) {
        var pw = $('#loginPw'), show = pw.type === 'password';
        pw.type = show ? 'text' : 'password';
        e.currentTarget.innerHTML = L.icon(show ? 'eye-off' : 'eye');
        e.currentTarget.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
        e.currentTarget.setAttribute('aria-pressed', String(show));
      });
      $('#loginId').addEventListener('input', function () { setErr('fId', 'eId', ''); alertBox.classList.remove('show'); });
      $('#loginPw').addEventListener('input', function () { setErr('fPw', 'ePw', ''); alertBox.classList.remove('show'); });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        alertBox.classList.remove('show');
        if (!validate()) return;
        btn.disabled = true; btn.textContent = 'Signing in…';
        L.auth.login($('#loginId').value, $('#loginPw').value, $('#remember').checked).then(function (r) {
          if (r.ok) { navigating = true; window.location.href = next; return; }
          btn.disabled = false; btn.textContent = 'Sign In';
          alertBox.textContent = r.error; alertBox.classList.add('show');
          $('#loginPw').value = ''; $('#loginPw').focus();
        }).catch(function () {
          btn.disabled = false; btn.textContent = 'Sign In';
          alertBox.textContent = 'Something went wrong. Please try again.'; alertBox.classList.add('show');
        });
      });
    }

    function render() { if (navigating) return; var u = L.auth.current(); if (u) signedInView(u); else formView(); }
    render();
    document.addEventListener('lsu:authchange', render);
  }
  if (window.LSU) window.LSU.ready(start);
})();
