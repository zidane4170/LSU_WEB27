/* Official LSU Executive Panel roster — transcribed from the supplied list.
   Keep names/designations in this file as the public source of truth. */
(function () {
  'use strict';
  window.LSU_EXECUTIVE_PANEL = {
    organization: "Lalmohan Students’ Union",
    title: "Executive Panel",
    tagline: "একা নয় যৌথ প্রয়াসে এগিয়ে যাব, বন্ধুর হলেও সে পথেই পা বাড়াবো।",
    session: "",
    groups: [
    {
        "designation": "President",
        "members": [
            "Fahim Shariar Mahin"
        ]
    },
    {
        "designation": "Senior Vice President",
        "members": [
            "Aritra Haldar",
            "Habibur Rahman",
            "Sami Patwary"
        ]
    },
    {
        "designation": "Vice President",
        "members": [
            "Abrarul Haque Saimun",
            "Jehad Hasan Abir",
            "Tamzid Hossain Siam",
            "Maruf Hasan Tarek",
            "Raisul Islam",
            "Md. Hojifa",
            "Arifur Rahman"
        ]
    },
    {
        "designation": "General Secretary",
        "members": [
            "Ariful Islam Rikto"
        ]
    },
    {
        "designation": "Joint Secretary",
        "members": [
            "Nazmir Hosen",
            "Mesbah Abid",
            "Minhajul Arafin",
            "Abdullah Jemad Fahim",
            "Jahidul Islam",
            "Nur Ahamed Siam"
        ]
    },
    {
        "designation": "Treasurer",
        "members": [
            "MD Rafin",
            "Amirul Islam",
            "Rifat Hossain",
            "Sakib Ahmed",
            "Sakil Hossain",
            "Mohammad Shamim",
            "MD Abdullah Al Howladar"
        ]
    },
    {
        "designation": "Administrative Secretary",
        "members": [
            "MD Shihabul Islam Tamim",
            "Ali Hasan",
            "Mohammad Rihad",
            "MD Raju",
            "Munshi Fahad",
            "MD Hamim Ahammad",
            "Za Hid",
            "Adil Rahaman",
            "MIM",
            "Arafat Rahman",
            "Sakhawat Hossen"
        ]
    },
    {
        "designation": "Planning & Strategy Secretary",
        "members": [
            "Rafsan Thamidis Juhan"
        ]
    },
    {
        "designation": "Organizing Secretary",
        "members": [
            "Mahmudul Hasan Rifat",
            "Jubayer Sunny",
            "A. K. M. Habibul Islam",
            "Irfan Sami",
            "Abdur Razzak Azim"
        ]
    },
    {
        "designation": "Office Secretary",
        "members": [
            "Taz Rian",
            "Tanvir Ahmed",
            "Refatul Islam",
            "Tahazin Anon",
            "Md Irteza Hassnain",
            "Shahriar Fahim"
        ]
    },
    {
        "designation": "Member Development Secretary",
        "members": [
            "Musfikur Rahman Maeen (22)"
        ]
    },
    {
        "designation": "Cultural Secretary",
        "members": [
            "Ibrahim Hosen Tamim (22)",
            "Riyad Bhuyan (22)",
            "Jannatul Ferdaus Mohona (22)"
        ]
    },
    {
        "designation": "Assistant Cultural Secretary",
        "members": [
            "Jakaria Amin Omi (24)",
            "Afrin sultana Mona(24)",
            "Hasiba Alam Akhi (24)"
        ]
    },
    {
        "designation": "Event Coordinator",
        "members": [
            "Md Mahedi Hasan Ovi (22)",
            "Maruf Hasan Ontor (22)",
            "Esrat Jahan Mishu (22)"
        ]
    },
    {
        "designation": "Assistant Event Coordinator",
        "members": [
            "Sajinur Zaman Srejon (24)",
            "Ahnaf Al Akif (24)",
            "Afrena Ferdaous Adiba (24)",
            "MD Salman Farsi (24)"
        ]
    },
    {
        "designation": "Public Relations Head",
        "members": [
            "Intiajul Haque Rafit (22)",
            "Safwan Hosen Tahanan (22)"
        ]
    },
    {
        "designation": "Assistant Public Relations Head",
        "members": [
            "Farabi Hoque Tohan (24)",
            "A.I.M. Jarif Rahman (24)",
            "Ashraful Islam Jidan (24)",
            "Muhammad Tasin (24)"
        ]
    },
    {
        "designation": "Academic Coordinator",
        "members": [
            "Prithvi Raj Das (22)",
            "Arefin Rahaman (22)",
            "Ahmed Lekon (22)"
        ]
    },
    {
        "designation": "Assistant Academic Coordinator",
        "members": [
            "Fokhrul Islam(24)",
            "MD. Arafatul Islam Alif (24)",
            "Samiya Akter (24)",
            "Rokon Hasan Kaikobad (24)"
        ]
    },
    {
        "designation": "Publication Head",
        "members": [
            "Md Eamin Rahman Apon (22)",
            "Md Jahid Hosen (22)"
        ]
    },
    {
        "designation": "Assistant Publication Head",
        "members": [
            "Md Mahady Hasan Munna (24)",
            "Shaon Hawlader (24)",
            "Riyad Hossain (24)",
            "MD Rehan Ahmed (24)"
        ]
    },
    {
        "designation": "IT Coordinator",
        "members": [
            "Tarikul Islam Nadim (23)"
        ]
    },
    {
        "designation": "Assistant IT Coordinator",
        "members": [
            "Omar Faruk (24)",
            "Abdullah Al Rafi ( 24)",
            "Rayhan Uddin Tamim (24)"
        ]
    },
    {
        "designation": "Sports Secretary",
        "members": [
            "M.Bappe (23)",
            "Iftekhar Alam Foysal (23)"
        ]
    },
    {
        "designation": "Assistant Sports Secretary",
        "members": [
            "Danial Araf(25)",
            "Tasrik Islam (25)",
            "Sajidul Islam Shuvo (25)"
        ]
    },
    {
        "designation": "Digital Media Coordinator",
        "members": [
            "Abir Hossain Nihal (23)"
        ]
    },
    {
        "designation": "Research & Analysis Coordinator",
        "members": [
            "A.N.M Shahjada Kaif (23)",
            "Umme Ayman Maysha (23)",
            "Meskat Jahan Dola (23)"
        ]
    },
    {
        "designation": "Asst. Career Development Secretary",
        "members": [
            "Jubayer Islam (25)",
            "Ashraful Islam Sani (25)",
            "Mohibul Haque Mohim(25)",
            "Riad Hossain (25)"
        ]
    },
    {
        "designation": "Partnership & Outreach Secretary",
        "members": [
            "Monir Mohammad Shemanto(23)",
            "Fateha Farin (23)",
            "Afnan Sneha (23)"
        ]
    },
    {
        "designation": "Asst. Partnership & Outreach Secretary",
        "members": [
            "Rafin Sheikh (25)",
            "Nabiul Alam Mugdho (25)",
            "Ishan Al Rahi (25)"
        ]
    },
    {
        "designation": "Volunteer Coordinator",
        "members": [
            "Tasfikur Rahman Niloy (23)",
            "Rahian Al Fahim (23)"
        ]
    },
    {
        "designation": "Assistant Volunteer Coordinator",
        "members": [
            "Md Adib Sikder (25)",
            "Asraful Islam Opu (25)",
            "Zihad Afridi (25)"
        ]
    },
    {
        "designation": "Blood Donation Coordinator",
        "members": [
            "Radowan Islam(23)",
            "Nahid Hasan Ove (23)"
        ]
    },
    {
        "designation": "Asst. Blood Donation Coordinator",
        "members": [
            "Ashraf Ali Thanovi (25)",
            "Ovisek Ahmed Abir (25)",
            "Md Shadman Muktadin Antu(25)"
        ]
    },
    {
        "designation": "Local Development Coordinator",
        "members": [
            "Md. Tasin Ahsan Akil (23)",
            "Utsha Karmokar (23)",
            "Fahim Faysal Mahir (23)"
        ]
    },
    {
        "designation": "Asst. Local Development Coordinator",
        "members": [
            "Samiul Rashid (25)",
            "Minhajul Islam Siam (25)",
            "MD Reon Ahmed (25)"
        ]
    },
    {
        "designation": "Asst. Research & Analysis Coordinator",
        "members": [
            "Jamil Hasan Antik(25)",
            "Tanha Alam Momo (25)",
            "Md. Abu Sufian Siddik Sadik (25)"
        ]
    },
    {
        "designation": "Legal Affairs & Policy Coordinator",
        "members": [
            "Najharul Islam (23)",
            "MD.Jehad Hosen (23)",
            "Anika Tabassum Raisah (23)",
            "Atia Afrin (23)"
        ]
    },
    {
        "designation": "Asst. Legal Affairs & Policy Coordinator",
        "members": [
            "Al Mahmud Jihan (25)",
            "Fayez Alam Zidan (25)",
            "Sobor Islam Emtu (25)"
        ]
    },
    {
        "designation": "Alumni Coordinator",
        "members": [
            "Tanisur Rahman (23)",
            "Md. Taimum Farabi (23)"
        ]
    },
    {
        "designation": "Assistant Alumni Coordinator",
        "members": [
            "Abu Rajin (25)",
            "Abdullah Al Redwan (25)",
            "Tahsin Al Mahadi (25)",
            "Taha Anowar (25)"
        ]
    },
    {
        "designation": "Women Affairs Secretary",
        "members": [
            "Maknun Maliha (23)",
            "Jerin Islam Esha (23)",
            "Juairia Uddin Rija (23)"
        ]
    },
    {
        "designation": "Assistant Women Affairs Secretary",
        "members": [
            "Tasnim Hossain Tanha (25)",
            "Maria Islam Othoi (25)"
        ]
    },
    {
        "designation": "Career Development Secretary",
        "members": [
            "Mazharul Islam Shuvo(23)",
            "Samin Ul Haq Ifty (23)"
        ]
    }
]
  };
})();
