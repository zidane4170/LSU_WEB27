(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$, esc = L.esc;
    var upcoming = [], past = [];
    L.data.EVENTS.forEach(function (e) {
      (L.isPast(e.date) ? past : upcoming).push(e);
    });
    function card(e) {
      return '<article class="card list-card">' +
        (e.image ? '<img src="' + esc(e.image) + '" alt="" style="width:100%;height:140px;object-fit:cover;border-radius:10px;margin-bottom:12px">' : '') +
        '<span class="tag">' + esc(e.category) + '</span>' +
        '<h3>' + esc(e.title) + '</h3>' +
        '<div class="meta">' + esc(L.fmtDate(e.date)) + (e.time ? ' · ' + esc(e.time) : '') + '</div>' +
        '<div class="meta">' + esc(e.venue) + '</div>' +
        '<p>' + esc(e.summary) + '</p></article>';
    }
    $('#upcomingList').innerHTML = upcoming.length ? upcoming.map(card).join('') : '<p style="color:var(--muted)">No upcoming events listed.</p>';
    $('#pastList').innerHTML = past.length ? past.map(card).join('') : '<p style="color:var(--muted)">No past events listed.</p>';
  }
  if (window.LSU && window.LSU.isReady) start();
  else document.addEventListener('lsu:ready', start, { once: true });
})();
