/* LSU core — shared by every page. Loaded once, after lsu-data.js.
   Provides: icons, verified badge, avatars, storage, session (auth), members,
   header/footer rendering, toast. Frontend-only: no real server security. */
(function () {
  'use strict';
  if (window.LSU) return; // never initialise twice
  var DATA = window.LSU_DATA || { MEMBERS: [], EVENTS: [], NOTICES: [] };

  /* ------------------------------------------------------------ config */
  var config = {
    name: 'Lalmohan Students’ Union',
    short: 'LSU',
    est: 2007,
    motto: 'Unity · Education · Progress',
    location: 'Lalmohan, Bhola, Bangladesh',
    // Add real URLs to show the matching icon in the footer. Empty = hidden (no fake links).
    social: { facebook: 'https://www.facebook.com/lalmohanstudentsunion/', instagram: '', youtube: '', linkedin: 'https://www.linkedin.com/company/lalmohan-students-union' }
  };

  /* ------------------------------------------------------------ helpers */
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }

  var mem = {};
  var store = {
    get: function (k, d) {
      try { var v = window.localStorage.getItem('lsu.' + k); return v == null ? d : JSON.parse(v); }
      catch (e) { return k in mem ? mem[k] : d; }
    },
    set: function (k, v) {
      mem[k] = v;
      try { window.localStorage.setItem('lsu.' + k, JSON.stringify(v)); } catch (e) { /* private mode */ }
    },
    del: function (k) {
      delete mem[k];
      try { window.localStorage.removeItem('lsu.' + k); } catch (e) { /* ignore */ }
    }
  };

  /* ------------------------------------------------------------ icons */
  var SPRITE = '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" style="position:absolute;width:0;height:0;overflow:hidden">' + [
    ['users', '<circle cx="9" cy="8" r="3.2"/><path d="M3 19c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5"/><circle cx="17" cy="9" r="2.5"/><path d="M17 14c2.4.2 4 1.9 4 4.5"/>'],
    ['board', '<circle cx="12" cy="9" r="5"/><path d="M8.7 13.2 7.5 21l4.5-2.5 4.5 2.5-1.2-7.8"/>'],
    ['calendar', '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M8 3v4M16 3v4M3.5 10h17"/>'],
    ['bell', '<path d="M6 16.5V11a6 6 0 1 1 12 0v5.5l1.5 1.5h-15L6 16.5Z"/><path d="M10 20.5a2.2 2.2 0 0 0 4 0"/>'],
    ['image', '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.7"/><path d="m4 18 5-5 3.5 3.5L16 13l4 4.5"/>'],
    ['code', '<path d="m8.5 8-4 4 4 4M15.5 8l4 4-4 4M13.5 5.5l-3 13"/>'],
    ['arrow', '<path d="M5 12h14M13 6l6 6-6 6"/>'],
    ['menu', '<path d="M4 7h16M4 12h16M4 17h16"/>'],
    ['close', '<path d="M6 6l12 12M18 6 6 18"/>'],
    ['chevron', '<path d="m6 9 6 6 6-6"/>'],
    ['user', '<circle cx="12" cy="8" r="3.8"/><path d="M4.5 20c.6-4 3.7-6 7.5-6s6.9 2 7.5 6"/>'],
    ['logout', '<path d="M9 4.5H6.5a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2H9M15 8l4 4-4 4M19 12H9.5"/>'],
    ['shield', '<path d="M12 3.5 5 6v5.5c0 4.2 2.9 7.2 7 9 4.1-1.8 7-4.8 7-9V6l-7-2.5Z"/><path d="m9 12 2.2 2.2L15.5 10"/>'],
    ['cap', '<path d="M3 8.5 12 4l9 4.5-9 4.5-9-4.5Z"/><path d="M7 11.2v4.6c0 1.4 2.2 2.7 5 2.7s5-1.3 5-2.7v-4.6M21 9v5.5"/>'],
    ['trend', '<path d="M3.5 17 9.5 11l4 4 7-7.5M15 7.5h5.5V13"/>'],
    ['mail', '<rect x="3.5" y="5.5" width="17" height="13" rx="2.5"/><path d="m4.5 7.5 7.5 6 7.5-6"/>'],
    ['pin', '<path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0C18.5 15.4 12 21 12 21Z"/><circle cx="12" cy="10" r="2.3"/>'],
    ['phone', '<path d="M5 4.5h3.5l1.5 4-2 1.3a11 11 0 0 0 5.2 5.2l1.3-2 4 1.5V18a2 2 0 0 1-2 2A14.5 14.5 0 0 1 3 6.5a2 2 0 0 1 2-2Z"/>'],
    ['clock', '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>'],
    ['eye', '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z"/><circle cx="12" cy="12" r="2.8"/>'],
    ['eye-off', '<path d="M3 3l18 18M10.6 5.7c.5-.1.9-.2 1.4-.2 6 0 9.5 6.5 9.5 6.5a16 16 0 0 1-3 3.8M6.5 7.3A16 16 0 0 0 2.5 12S6 18.5 12 18.5c1.6 0 3-.4 4.2-1M9.9 9.9a2.8 2.8 0 0 0 4 4"/>'],
    ['facebook', '<path fill="currentColor" stroke="none" d="M13.5 21v-8h2.7l.5-3.2h-3.2V7.8c0-.9.4-1.6 1.7-1.6h1.6V3.4c-.3 0-1.3-.2-2.4-.2-2.5 0-4 1.5-4 4.1v2.5H7.5V13h2.9v8h3.1Z"/>'],
    ['instagram', '<rect x="4" y="4" width="16" height="16" rx="4.5"/><circle cx="12" cy="12" r="3.7"/><circle cx="16.8" cy="7.2" r=".7" fill="currentColor" stroke="none"/>'],
    ['youtube', '<rect x="3" y="6" width="18" height="12" rx="3.5"/><path fill="currentColor" stroke="none" d="m10.5 9.5 4.5 2.5-4.5 2.5v-5Z"/>'],
    ['linkedin', '<path fill="currentColor" stroke="none" d="M4 9.5h3.2V20H4V9.5Zm1.6-5.2a1.9 1.9 0 1 1 0 3.8 1.9 1.9 0 0 1 0-3.8ZM10 9.5h3v1.5c.6-1 1.8-1.8 3.4-1.8 3 0 3.6 2 3.6 4.5V20h-3.2v-5.4c0-1.3 0-2.6-1.7-2.6s-1.9 1.2-1.9 2.5V20H10V9.5Z"/>']
  ].map(function (i) { return '<symbol id="i-' + i[0] + '" viewBox="0 0 24 24">' + i[1] + '</symbol>'; }).join('') +
    '<symbol id="i-verified" viewBox="0 0 24 24"><path fill="#12a15f" d="M12 2.4A4.11 4.11 0 0 1 18.79 5.21 4.11 4.11 0 0 1 21.6 12 4.11 4.11 0 0 1 18.79 18.79 4.11 4.11 0 0 1 12 21.6 4.11 4.11 0 0 1 5.21 18.79 4.11 4.11 0 0 1 2.4 12 4.11 4.11 0 0 1 5.21 5.21 4.11 4.11 0 0 1 12 2.4Z"/><path fill="none" stroke="#fff" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round" d="M7.6 12.4l3 3 5.9-6.4"/></symbol></svg>';

  function icon(name, cls) {
    return '<svg class="i' + (cls ? ' ' + cls : '') + '" aria-hidden="true" focusable="false"><use href="#i-' + name + '"></use></svg>';
  }
  // Facebook-style green check. Render ONLY for admin-verified members.
  function verifiedBadge() {
    return '<svg class="vbadge" viewBox="0 0 24 24" role="img" aria-label="Verified by LSU"><title>Verified by LSU</title><use href="#i-verified"></use></svg>';
  }
  function avatar(name) {
    var parts = String(name || 'Guest').trim().split(/\s+/);
    var ini = ((parts[0] || 'G')[0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#087443"/><stop offset="1" stop-color="#004d38"/></linearGradient></defs><rect width="96" height="96" fill="url(#g)"/><text x="48" y="48" dy=".35em" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="36" font-weight="700" fill="#fff">' + esc(ini) + '</text></svg>';
    return 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
  }

  /* ------------------------------------------------------------ members & session */
  var ROLE_ORDER = ['President', 'Vice President', 'General Secretary', 'Joint Secretary', 'Organizational Secretary', 'Finance Secretary', 'Office Secretary', 'Public Relations & Media', 'Treasurer', 'Executive'];

  function accounts() { return store.get('accounts', []); }
  function patches() { return store.get('memberPatches', {}); }

  function allMembers() {
    var p = patches();
    var seeded = DATA.MEMBERS.map(function (m) { return Object.assign({}, m, p[m.id] || {}); });
    var reg = accounts().map(function (a) {
      return Object.assign({ role: 'Member', category: 'General Member', verified: false, status: 'pending' }, a, p[a.id] || {});
    });
    return seeded.concat(reg);
  }
  function findMember(id) {
    var all = allMembers();
    for (var i = 0; i < all.length; i++) if (all[i].id === id) return all[i];
    return null;
  }

  /* ---- session: localStorage when "remember me", sessionStorage otherwise ---- */
  function readSession() {
    var v = null;
    try { v = window.sessionStorage.getItem('lsu.session'); } catch (e) { /* ignore */ }
    if (!v) { try { v = window.localStorage.getItem('lsu.session'); } catch (e) { /* ignore */ } }
    if (v) { try { return JSON.parse(v); } catch (e) { return null; } }
    return mem.session || null;
  }
  function writeSession(id, remember) {
    var val = JSON.stringify({ id: id, at: Date.now() });
    clearSession();
    mem.session = { id: id };
    // TEMP compatibility for pages not yet migrated (/members). Removed when that page is rebuilt.
    try { window.localStorage.setItem('lsuLoggedIn', '1'); window.localStorage.setItem('lsuCurrentMember', id); } catch (e) { /* ignore */ }
    try { (remember ? window.localStorage : window.sessionStorage).setItem('lsu.session', val); } catch (e) { /* memory only */ }
  }
  function clearSession() {
    delete mem.session;
    try { window.sessionStorage.removeItem('lsu.session'); } catch (e) { /* ignore */ }
    try { window.localStorage.removeItem('lsu.session'); } catch (e) { /* ignore */ }
  }

  function currentUser() {
    var s = readSession();
    if (s && s.id) {
      var m = findMember(s.id);
      if (m && m.status !== 'rejected' && m.status !== 'suspended') return m;
    }
    return null;
  }
  function isAdmin(u) { return !!(u && (u.admin === true || u.adminRole === 'main' || u.adminRole === 'media')); }

  function logout(redirect) {
    clearSession();
    try { window.localStorage.removeItem('lsuLoggedIn'); window.localStorage.removeItem('lsuCurrentMember'); } catch (e) { /* ignore */ }
    document.dispatchEvent(new CustomEvent('lsu:authchange'));
    if (redirect) window.location.href = redirect;
  }

  /* Authentication is handled by Firebase; no client-side demo credentials. */
  var SEED_LOGINS = [];
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  function strongPassword(p) { return typeof p === 'string' && p.length >= 8 && /[A-Za-z]/.test(p) && /\d/.test(p); }

  function login(identifier, password, remember) {
    var id = String(identifier || '').trim().toLowerCase();
    var generic = { ok: false, error: 'Incorrect email / Member ID or password.' };
    var seed = SEED_LOGINS.filter(function (x) { return x.login === id || x.id.toLowerCase() === id; })[0];
    var acct = accounts().filter(function (a) { return String(a.email).toLowerCase() === id || String(a.id).toLowerCase() === id || String(a.memberId || '').toLowerCase() === id; })[0];
    if (seed) {
      return Promise.all([sha256(password), sha256(seed.pass)]).then(function (h) {
        if (h[0] !== h[1]) return generic;
        writeSession(seed.id, remember); document.dispatchEvent(new CustomEvent('lsu:authchange'));
        return { ok: true, user: findMember(seed.id) };
      });
    }
    if (acct) {
      return sha256(acct.salt + ':' + password).then(function (h) {
        if (h !== acct.passHash) return generic;
        if (acct.status === 'rejected' || acct.status === 'suspended') return { ok: false, error: 'This account is not active. Please contact LSU.' };
        writeSession(acct.id, remember); document.dispatchEvent(new CustomEvent('lsu:authchange'));
        return { ok: true, user: findMember(acct.id) };
      });
    }
    return sha256('x').then(function () { return generic; });
  }

  // Anyone may register. The account is ALWAYS created Unverified / Member / pending —
  // nothing the caller passes can change that.
  function register(d) {
    var email = String(d.email || '').trim().toLowerCase();
    if (accounts().some(function (a) { return String(a.email).toLowerCase() === email; }) ||
        SEED_LOGINS.some(function (x) { return x.login === email; })) {
      return Promise.resolve({ ok: false, field: 'email', error: 'An account with this email already exists.' });
    }
    var salt = randomId(8);
    return sha256(salt + ':' + d.password).then(function (hash) {
      var acct = {
        id: 'REG-' + randomId(4).toUpperCase(), memberId: '', name: String(d.name || '').trim(), email: email, phone: String(d.phone || '').trim(),
        batch: String(d.batch || '').trim(), gender: d.gender || '', salt: salt, passHash: hash, createdAt: new Date().toISOString(),
        role: 'Member', category: 'General Member', verified: false, status: 'pending'
      };
      var list = accounts(); list.push(acct); store.set('accounts', list);
      if (d.signIn !== false) { writeSession(acct.id, !!d.remember); document.dispatchEvent(new CustomEvent('lsu:authchange')); }
      return { ok: true, user: findMember(acct.id) };
    });
  }

  /* ---- profile edits: members may change ONLY these fields on their own record ---- */
  var OWN_EDITABLE = ['name', 'gender', 'dob', 'location', 'phone', 'address', 'bio', 'profession', 'org', 'designation', 'skills', 'interests',
    'facebook', 'linkedin', 'website', 'batch', 'sscInstitution', 'hscInstitution', 'hsc', 'university', 'subject', 'bachelor', 'master', 'photo'];
  function updateOwn(patch) {
    var u = currentUser();
    if (!u) return { ok: false, error: 'Not signed in.' };
    var clean = {};
    OWN_EDITABLE.forEach(function (k) { if (Object.prototype.hasOwnProperty.call(patch, k)) clean[k] = patch[k]; });
    if (clean.name !== undefined && !String(clean.name).trim()) return { ok: false, error: 'Name cannot be empty.' };
    var accts = accounts(), idx = -1;
    accts.forEach(function (a, i) { if (a.id === u.id) idx = i; });
    if (idx > -1) { Object.assign(accts[idx], clean); store.set('accounts', accts); }
    else { var p = patches(); p[u.id] = Object.assign({}, p[u.id] || {}, clean); store.set('memberPatches', p); }
    document.dispatchEvent(new CustomEvent('lsu:authchange'));
    return { ok: true, user: findMember(u.id) };
  }
  // A member may ASK to be verified; only an admin can grant it.
  function requestVerification() {
    var u = currentUser();
    if (!u || u.verified) return { ok: false };
    var accts = accounts(), idx = -1;
    accts.forEach(function (a, i) { if (a.id === u.id) idx = i; });
    var req = { status: 'pending', at: new Date().toISOString() };
    if (idx > -1) { accts[idx].verifyRequest = req; store.set('accounts', accts); }
    else { var p = patches(); p[u.id] = Object.assign({}, p[u.id] || {}, { verifyRequest: req }); store.set('memberPatches', p); }
    return { ok: true, user: findMember(u.id) };
  }
  function memberIdLabel(m) { return m.memberId || (/^LSU-/.test(m.id) ? m.id : 'Assigned after verification'); }

  /* ---- legacy admin API; Firebase bridge enforces production access ---- */
  function requireAdmin() {
    var u = currentUser();
    if (!isAdmin(u)) return null;
    return u;
  }
  function applyMemberPatch(id, patch) {
    var accts = accounts(), idx = -1;
    accts.forEach(function (a, i) { if (a.id === id) idx = i; });
    if (idx > -1) {
      Object.assign(accts[idx], patch);
      store.set('accounts', accts);
    } else {
      var p = patches();
      p[id] = Object.assign({}, p[id] || {}, patch);
      store.set('memberPatches', p);
    }
    document.dispatchEvent(new CustomEvent('lsu:authchange'));
    return findMember(id);
  }
  function nextLocalMemberId() {
    var max = 1000;
    allMembers().forEach(function (m) { var n = parseInt(m.memberId, 10); if (isFinite(n) && n > max) max = n; });
    return String(max + 1);
  }
  function adminSetVerified(id, verified) {
    if (!requireAdmin()) return { ok: false, error: 'Admin access required.' };
    var m = findMember(id);
    if (!m) return { ok: false, error: 'Member not found.' };
    var patch = { verified: !!verified };
    if (verified) {
      patch.verifyRequest = null;
      if (!m.memberId) patch.memberId = nextLocalMemberId();
      if (m.status === 'pending') patch.status = 'active';
    }
    return { ok: true, user: applyMemberPatch(id, patch) };
  }
  function adminSetStatus(id, status) {
    if (!requireAdmin()) return { ok: false, error: 'Admin access required.' };
    if (['pending', 'active', 'rejected', 'suspended'].indexOf(status) < 0) return { ok: false, error: 'Invalid status.' };
    var m = findMember(id);
    if (!m) return { ok: false, error: 'Member not found.' };
    return { ok: true, user: applyMemberPatch(id, { status: status }) };
  }
  function adminApprove(id) {
    if (!requireAdmin()) return { ok: false, error: 'Admin access required.' };
    var m = findMember(id);
    if (!m) return { ok: false, error: 'Member not found.' };
    var patch = { status: 'active' };
    return { ok: true, user: applyMemberPatch(id, patch) };
  }
  function adminReject(id) {
    return adminSetStatus(id, 'rejected');
  }
  function adminSetRole(id, role, category) {
    if (!requireAdmin()) return { ok: false, error: 'Admin access required.' };
    var m = findMember(id);
    if (!m) return { ok: false, error: 'Member not found.' };
    var patch = {};
    if (role) patch.role = String(role);
    if (category) patch.category = String(category);
    return { ok: true, user: applyMemberPatch(id, patch) };
  }
  function adminSetMemberId(id, memberId) {
    if (!requireAdmin()) return { ok: false, error: 'Admin access required.' };
    var m = findMember(id);
    if (!m) return { ok: false, error: 'Member not found.' };
    return { ok: true, user: applyMemberPatch(id, { memberId: String(memberId || '').trim() }) };
  }
  function adminResetPassword(id, newPass) {
    if (!requireAdmin()) return { ok: false, error: 'Admin access required.' };
    if (!strongPassword(newPass)) return { ok: false, error: 'Password must be at least 8 characters with a letter and a number.' };
    var accts = accounts(), idx = -1;
    accts.forEach(function (a, i) { if (a.id === id) idx = i; });
    if (idx < 0) return { ok: false, error: 'Only Firebase accounts can have passwords reset.' };
    var salt = randomId(8);
    return sha256(salt + ':' + newPass).then(function (hash) {
      accts[idx].salt = salt;
      accts[idx].passHash = hash;
      store.set('accounts', accts);
      return { ok: true };
    });
  }
  function changePassword(currentPass, newPass) {
    var u = currentUser();
    if (!u) return Promise.resolve({ ok: false, error: 'Not signed in.' });
    if (!strongPassword(newPass)) return Promise.resolve({ ok: false, error: 'New password must be at least 8 characters with a letter and a number.' });
    var accts = accounts(), idx = -1;
    accts.forEach(function (a, i) { if (a.id === u.id) idx = i; });
    if (idx < 0) {
      // Legacy compatibility: no client-side seed accounts
      var seed = SEED_LOGINS.filter(function (x) { return x.id === u.id; })[0];
      if (!seed) return Promise.resolve({ ok: false, error: 'Password changes are available through Firebase accounts.' });
      return Promise.all([sha256(currentPass), sha256(seed.pass)]).then(function (h) {
        if (h[0] !== h[1]) return { ok: false, error: 'Current password is incorrect.' };
        return { ok: false, error: 'Password changes are available only for Firebase accounts.' };
      });
    }
    return sha256(accts[idx].salt + ':' + currentPass).then(function (h) {
      if (h !== accts[idx].passHash) return { ok: false, error: 'Current password is incorrect.' };
      var salt = randomId(8);
      return sha256(salt + ':' + newPass).then(function (nh) {
        accts[idx].salt = salt;
        accts[idx].passHash = nh;
        store.set('accounts', accts);
        return { ok: true };
      });
    });
  }
  function requestPasswordReset(email) {
    // Legacy fallback is disabled; Firebase handles password reset.
    var e = String(email || '').trim().toLowerCase();
    if (!EMAIL_RE.test(e)) return { ok: false, error: 'Enter a valid email address.' };
    var acct = accounts().filter(function (a) { return String(a.email).toLowerCase() === e; })[0];
    var seed = SEED_LOGINS.filter(function (x) { return x.login === e; })[0];
    if (!acct && !seed) {
      // Do not reveal whether the email exists
      return { ok: true, message: 'If an account exists for that email, a reset link has been prepared.' };
    }
    var token = randomId(16);
    store.set('resetToken', { email: e, token: token, at: Date.now(), id: (acct && acct.id) || (seed && seed.id) });
    return { ok: false, error: 'Password reset requires Firebase authentication.' };
  }
  function completePasswordReset(token, newPass) {
    if (!strongPassword(newPass)) return Promise.resolve({ ok: false, error: 'Password must be at least 8 characters with a letter and a number.' });
    var rt = store.get('resetToken', null);
    if (!rt || rt.token !== token || (Date.now() - rt.at) > 3600000) {
      return Promise.resolve({ ok: false, error: 'This reset link is invalid or has expired.' });
    }
    var accts = accounts(), idx = -1;
    accts.forEach(function (a, i) { if (a.id === rt.id) idx = i; });
    if (idx < 0) {
      store.del('resetToken');
      return Promise.resolve({ ok: false, error: 'Password reset is available only for Firebase accounts.' });
    }
    var salt = randomId(8);
    return sha256(salt + ':' + newPass).then(function (hash) {
      accts[idx].salt = salt;
      accts[idx].passHash = hash;
      store.set('accounts', accts);
      store.del('resetToken');
      return { ok: true };
    });
  }

  function isPast(iso) {
    var d = new Date(iso + 'T23:59:59');
    return d.getTime() < Date.now();
  }
  function fmtDate(iso, opts) {
    var d = new Date(iso + 'T00:00:00');
    return d.toLocaleDateString('en-GB', opts || { day: '2-digit', month: 'short', year: 'numeric' });
  }
  function safeNext(n, fallback) { return /^[a-z0-9_\-\/]+\.html(\?[\w=&%\-.]*)?$/i.test(n || '') ? n : fallback; }
  function loginUrl(next) { return '/login' + (next ? '?next=' + encodeURIComponent(next) : ''); }

  /* ------------------------------------------------------------ toast */
  var toastTimer;
  function toast(msg, type) {
    var t = $('#lsuToast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'lsuToast';
      t.className = 'toast';
      t.setAttribute('role', 'status');
      t.setAttribute('aria-live', 'polite');
      document.body.appendChild(t);
    }
    t.className = 'toast show' + (type ? ' toast-' + type : '');
    t.textContent = msg;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 3600);
  }

  /* ------------------------------------------------------------ chrome: header & footer */
  var NAV = [
    ['home', 'Home', '/home'],
    ['about', 'About', '/about'],
    ['board', 'Executive Board', '/executive'],
    ['members', 'Members', '/members'],
    ['events', 'Events', '/events'],
    ['gallery', 'Gallery', '/gallery'],
    ['departments', 'Programs', 'departments.html'],
    ['contact', 'Contact', '/contact']
  ];

  function pageKey() { return (document.body && document.body.dataset.page) || ''; }
  function link(item, extra) {
    var cur = pageKey() === item[0];
    return '<a href="' + item[2] + '"' + (cur ? ' aria-current="page"' : '') + (extra || '') + '>' + esc(item[1]) + '</a>';
  }
  function firstName(u) { return String(u.name || 'Member').split(' ')[0]; }

  function accountMarkup(u) {
    if (!u) {
      return '<a class="account-btn" id="accountBtn" href="/login" aria-label="Sign in">' +
        '<img class="avatar" src="' + guestAvatar() + '" alt="" width="44" height="44"></a>';
    }
    var img = u.photo || avatar(u.name);
    return '<a class="account-btn" id="accountBtn" href="/profile" aria-label="My profile">' +
      '<img class="avatar" src="' + esc(img) + '" onerror="this.onerror=null;this.src=\'' + avatar(u.name) + '\'" alt="Profile photo" width="44" height="44"></a>';
  }

  function guestAvatar() {
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 96"><rect width="96" height="96" fill="#eaf7f1"/><circle cx="48" cy="37" r="16" fill="#006747"/><path d="M16 92c3-22 15-32 32-32s29 10 32 32z" fill="#087443"/></svg>';
    return 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
  }

  function headerMarkup(u) {
    var extra = '';
    if (u) {
      extra += link(['profile', 'My Profile', '/profile']);
      /* Admin Panel is intentionally not listed in the public/global navigation. Main Admins access it from their profile. */
      extra += '<button type="button" class="drawer-logout" data-action="logout">Sign out</button>';
    } else {
      extra += link(['login', 'Sign In', '/login']);
      extra += link(['register', 'Register', '/register']);
    }
    return '<header class="site-header" id="siteHeader"><div class="container nav">' +
      '<button type="button" class="nav-toggle" id="navToggle" aria-expanded="false" aria-controls="navDrawer" aria-label="Open menu">' + icon('menu') + '</button>' +
      '<a class="brand" href="/home" aria-label="' + esc(config.name) + ' — Home"><img src="assets/logo.png" alt="" width="46" height="46"><span class="brand-text"><strong>Lalmohan Students&rsquo;</strong><strong>Union</strong></span></a>' +
      '<div class="nav-actions" id="navActions">' + accountMarkup(u) + '</div>' +
      '</div><nav class="nav-drawer" id="navDrawer" aria-label="Main menu" hidden>' +
      NAV.map(function (n) { return link(n); }).join('') +
      link(['technology', 'Technology & Development', 'technology.html']) +
      extra +
      '</nav></header>';
  }

  function footerMarkup(u) {
    var soc = Object.keys(config.social).filter(function (k) { return config.social[k]; }).map(function (k) {
      return '<a class="social-link" href="' + esc(config.social[k]) + '" target="_blank" rel="noopener noreferrer" aria-label="' + k.charAt(0).toUpperCase() + k.slice(1) + '">' + icon(k) + '</a>';
    }).join('');
    return '<footer class="site-footer"><div class="container">' +
      '<div class="footer-grid">' +
      '<div class="footer-about"><a class="footer-brand" href="/home"><img src="assets/logo.png" alt="" width="44" height="44"><span><strong>' + esc(config.name) + '</strong><small>Est. ' + config.est + ' · ' + esc(config.motto) + '</small></span></a>' +
      '<p>A student-led community connecting the students and alumni of Lalmohan through unity, education and progress.</p>' +
      (soc ? '<div class="social">' + soc + '</div>' : '') + '</div>' +
      '<div><h2 class="footer-title">Explore</h2><ul><li><a href="/home">Home</a></li><li><a href="/about">About LSU</a></li><li><a href="/executive">Executive Board</a></li><li><a href="/events">Events</a></li><li><a href="/gallery">Gallery</a></li></ul></div>' +
      '<div><h2 class="footer-title">Members</h2><ul><li><a href="/members">Members Directory</a></li>' +
      (u ? '<li><a href="/profile">My Profile</a></li>' : '<li><a href="/login">Sign In</a></li><li><a href="/register">Register</a></li><li><a href="/forgot-password">Forgot Password</a></li>') +
      '</ul></div>' +
      '<div><h2 class="footer-title">Get in touch</h2><ul class="footer-contact"><li>' + icon('pin') + '<span>' + esc(config.location) + '</span></li><li><a href="/contact">' + icon('mail') + '<span>Contact LSU</span></a></li><li><a href="technology.html">' + icon('code') + '<span>Technology &amp; Development</span></a></li></ul></div>' +
      '</div>' +
      '<div class="footer-bottom"><span>© ' + new Date().getFullYear() + ' ' + esc(config.name) + '. All rights reserved.</span><span>' + esc(config.motto) + '</span></div>' +
      '</div></footer>';
  }

  var drawerOpen = false;
  function setDrawer(open) {
    var d = $('#navDrawer'), b = $('#navToggle');
    if (!d || !b) return;
    drawerOpen = open;
    d.hidden = !open;
    b.setAttribute('aria-expanded', String(open));
    b.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    b.innerHTML = icon(open ? 'close' : 'menu');
    document.documentElement.classList.toggle('nav-open', open);
  }
  function renderChrome() {
    // Always read the active auth provider; Firebase replaces the legacy local session API.
    var u = window.LSU && window.LSU.auth ? window.LSU.auth.current() : currentUser();
    var h = $('#site-header'), f = $('#site-footer');
    drawerOpen = false;
    document.documentElement.classList.remove('nav-open');
    if (h) h.innerHTML = headerMarkup(u);
    if (f) f.innerHTML = footerMarkup(u);
  }

  function bindOnce() {
    document.addEventListener('click', function (e) {
      var t = e.target;
      if (t.closest('#navToggle')) { setDrawer(!drawerOpen); return; }
      if (t.closest('#navDrawer a')) setDrawer(false);
      if (!t.closest('#navDrawer')) setDrawer(false);
      if (t.closest('[data-action="logout"]')) {
        var protectedPage = document.body.dataset.access && document.body.dataset.access !== 'public';
        var authApi = window.LSU && window.LSU.auth;
        if (authApi && typeof authApi.logout === 'function') {
          Promise.resolve(authApi.logout(protectedPage ? '/home' : null)).catch(function (err) {
            toast((err && err.message) || 'Could not sign out. Please try again.', 'error');
          });
        } else {
          logout(protectedPage ? '/home' : null);
        }
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (drawerOpen) { setDrawer(false); var b = $('#navToggle'); if (b) b.focus(); }
    });
        // Another tab signed in/out → refresh this tab's UI. No redirects here.
    window.addEventListener('storage', function (e) {
      if (e.key === 'lsu.session' || e.key === 'lsuLoggedIn') document.dispatchEvent(new CustomEvent('lsu:authchange'));
    });
    document.addEventListener('lsu:authchange', renderChrome);
  }

  function init() {
    if (!$('#lsu-sprite')) {
      var d = document.createElement('div');
      d.id = 'lsu-sprite';
      d.innerHTML = SPRITE;
      document.body.insertBefore(d, document.body.firstChild);
    }
    renderChrome();
    bindOnce();
    document.dispatchEvent(new CustomEvent('lsu:ready'));
  }

  window.LSU = {
    config: config, data: DATA, store: store, esc: esc, $: $, $$: $$, icon: icon, guestAvatar: guestAvatar, verifiedBadge: verifiedBadge,
    avatar: avatar, toast: toast, fmtDate: fmtDate, isPast: isPast, loginUrl: loginUrl, safeNext: safeNext, ROLE_ORDER: ROLE_ORDER,
    members: { all: allMembers, find: findMember },
    auth: {
      current: currentUser, isAdmin: isAdmin, logout: logout, login: login, register: register,
      strongPassword: strongPassword, isEmail: function (v) { return EMAIL_RE.test(v); },
      changePassword: changePassword, requestPasswordReset: requestPasswordReset, completePasswordReset: completePasswordReset
    },
    profile: { updateOwn: updateOwn, requestVerification: requestVerification, memberIdLabel: memberIdLabel },
    admin: {
      setVerified: adminSetVerified, setStatus: adminSetStatus, approve: adminApprove, reject: adminReject,
      setRole: adminSetRole, setMemberId: adminSetMemberId, resetPassword: adminResetPassword
    },
    ready: function (fn) {
      if (window.LSU.isReady) fn(); else document.addEventListener('lsu:ready', fn, { once: true });
    }
  };

  document.addEventListener('lsu:ready', function () { window.LSU.isReady = true; }, { once: true });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
