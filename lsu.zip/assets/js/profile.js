/* Member Profile. Private page: shows a Sign In / Register prompt (no redirect) when signed out. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$, esc = L.esc;
    var root = $('#profileRoot');
    var params = new URLSearchParams(window.location.search);
    var viewId = params.get('id');
    var editing = null;
    var thisYear = new Date().getFullYear();

    /* ---- field definitions (only these are member-editable; see LSU.profile.updateOwn) ---- */
    var yearRule = function (v) { return !v || (/^\d{4}$/.test(v) && +v >= 1950 && +v <= thisYear + 6) ? '' : 'Enter a valid 4-digit year.'; };
    var urlRule = function (v) { if (!v) return ''; try { var u = new URL(v); return /^https?:$/.test(u.protocol) ? '' : 'Use a link starting with https://'; } catch (e) { return 'Enter a valid link, e.g. https://example.com'; } };
    var SECTIONS = [
      { id: 'about', title: 'About', sub: 'A short introduction.', fields: [
        { k: 'bio', l: 'Short bio', t: 'textarea', wide: true, max: 400 }] },
      { id: 'personal', title: 'Personal information', fields: [
        { k: 'name', l: 'Full name', req: true, max: 80 },
        { k: 'gender', l: 'Gender', t: 'select', opts: ['', 'Female', 'Male', 'Other', 'Prefer not to say'] },
        { k: 'dob', l: 'Date of birth', t: 'date', priv: true, rule: function (v) { if (!v) return ''; var d = new Date(v); return isNaN(d) || d > new Date() || d.getFullYear() < 1940 ? 'Enter a valid date of birth.' : ''; } },
        { k: 'location', l: 'Present location', max: 80 }] },
      { id: 'contact', title: 'Contact', sub: 'Visible only to you.', priv: true, fields: [
        { k: 'email', l: 'Email (used to sign in)', locked: 'email' },
        { k: 'phone', l: 'Mobile number', t: 'tel', rule: function (v) { return !v || /^[+\d][\d\s-]{6,18}$/.test(v) ? '' : 'Enter a valid phone number.'; } },
        { k: 'address', l: 'Present address', wide: true, max: 160 }] },
      { id: 'professional', title: 'Professional', fields: [
        { k: 'profession', l: 'Current profession', max: 80 }, { k: 'org', l: 'Organization', max: 80 },
        { k: 'designation', l: 'Designation', max: 80 }, { k: 'skills', l: 'Skills / expertise', max: 160 },
        { k: 'interests', l: 'Interests', wide: true, max: 160 }] },
      { id: 'social', title: 'Social links', fields: [
        { k: 'facebook', l: 'Facebook', t: 'url', rule: urlRule }, { k: 'linkedin', l: 'LinkedIn', t: 'url', rule: urlRule },
        { k: 'website', l: 'Website / portfolio', t: 'url', rule: urlRule, wide: true }] },
      { id: 'education', title: 'Education', fields: [
        { k: 'batch', l: 'SSC passing year (batch)', req: true, rule: function (v) { return /^\d{4}$/.test(v) && +v >= 1950 && +v <= thisYear + 6 ? '' : 'Enter a valid 4-digit year.'; } },
        { k: 'sscInstitution', l: 'SSC institution', max: 100 }, { k: 'hsc', l: 'HSC passing year', rule: yearRule },
        { k: 'hscInstitution', l: 'HSC institution', max: 100 }, { k: 'university', l: 'University / college', max: 100 },
        { k: 'subject', l: 'Subject / department', max: 100 }, { k: 'bachelor', l: 'Bachelor’s year', rule: yearRule }, { k: 'master', l: 'Master’s year', rule: yearRule }] }
    ];

    function val(m, f) { return f.locked === 'email' ? m.email : m[f.k]; }
    function show(f, v) {
      if (!v) return '<dd class="empty">Not added</dd>';
      if (f.t === 'url') { try { var u = new URL(v); if (/^https?:$/.test(u.protocol)) return '<dd><a class="btn btn-outline btn-sm social-view-btn" href="' + esc(u.href) + '" target="_blank" rel="noopener noreferrer">View</a></dd>'; } catch (e) { /* fall through */ } }
      if (f.t === 'date') return '<dd>' + esc(L.fmtDate(v)) + '</dd>';
      return '<dd>' + esc(v) + '</dd>';
    }

    function completion(m) {
      var keys = ['name', 'bio', 'gender', 'location', 'phone', 'profession', 'org', 'skills', 'batch', 'sscInstitution', 'university', 'photo'];
      return Math.round(keys.filter(function (k) { return m[k]; }).length / keys.length * 100);
    }

    /* ---------- views ---------- */
    function loadingView() {
      document.title = 'Loading profile — LSU';
      root.innerHTML = '<section class="card gate profile-loading"><div class="loading-spinner" aria-hidden="true"></div><h1>Loading your profile</h1><p>Checking your secure LSU account session…</p></section>';
    }

    function gateView() {
      var loadError = L.auth.loadError && L.auth.loadError();
      if (loadError) {
        document.title = 'Profile unavailable — LSU';
        root.innerHTML = '<section class="card gate"><h1>Profile unavailable</h1><p>' + esc(loadError) + '</p><div class="gate-actions"><button class="btn btn-primary" type="button" onclick="window.location.reload()">Try again</button></div></section>';
        return;
      }
      document.title = 'Sign in to view profiles — LSU';
      var next = '/profile' + (viewId ? '?id=' + encodeURIComponent(viewId) : '');
      root.innerHTML = '<section class="card gate"><img class="avatar" src="' + L.guestAvatar() + '" alt="" width="84" height="84">' +
        '<h1>Sign in to view your profile</h1><p>Member profiles are available to signed-in members. Sign in to continue, or create a free account to join the LSU community.</p>' +
        '<div class="gate-actions"><a class="btn btn-primary" href="' + L.loginUrl(next) + '">Sign In</a><a class="btn btn-outline" href="/register">Register</a></div></section>';
    }

    function notFoundView() {
      document.title = 'Member not found — LSU';
      root.innerHTML = '<section class="card gate"><h1>Member not found</h1><p>This profile does not exist or is no longer available.</p><div class="gate-actions"><a class="btn btn-primary" href="/members">Back to Members</a></div></section>';
    }

    function statusPill(m) {
      if (m.verified) return '<span class="status status-ok">' + L.verifiedBadge() + ' Verified member</span>';
      if (m.verifyRequest && m.verifyRequest.status === 'pending') return '<span class="status status-wait">Verification pending</span>';
      return '<span class="status status-off">Unverified</span>';
    }

    function infoGrid(m, fields, own) {
      return '<dl class="info">' + fields.map(function (f) {
        if (f.priv && !own) return '';
        return '<div class="info-item' + (f.wide ? ' wide' : '') + '"><dt>' + esc(f.l) + (f.locked ? ' <span class="lock">Fixed</span>' : '') + '</dt>' + show(f, val(m, f)) + '</div>';
      }).join('') + '</dl>';
    }

    function formFor(m, sec) {
      return '<form class="edit-form" data-form="' + sec.id + '" novalidate><div class="alert alert-error" role="alert"></div><div class="form-grid">' + sec.fields.map(function (f) {
        var id = 'f_' + f.k, v = m[f.k] || '', span = f.wide ? ' style="grid-column:1/-1"' : '';
        if (f.locked) return '<div class="field"' + span + '><label for="' + id + '">' + esc(f.l) + '</label><input class="input" id="' + id + '" value="' + esc(m.email) + '" readonly></div>';
        var ctl;
        if (f.t === 'textarea') ctl = '<textarea class="textarea" id="' + id + '" name="' + f.k + '" maxlength="' + (f.max || 400) + '">' + esc(v) + '</textarea>';
        else if (f.t === 'select') ctl = '<select class="select" id="' + id + '" name="' + f.k + '">' + f.opts.map(function (o) { return '<option value="' + esc(o) + '"' + (o === v ? ' selected' : '') + '>' + (o || 'Select…') + '</option>'; }).join('') + '</select>';
        else ctl = '<input class="input" id="' + id + '" name="' + f.k + '" type="' + (f.t || 'text') + '" value="' + esc(v) + '"' + (f.max ? ' maxlength="' + f.max + '"' : '') + (f.t === 'date' ? ' max="' + new Date().toISOString().slice(0, 10) + '"' : '') + (f.t === 'tel' ? ' inputmode="tel" autocomplete="tel"' : '') + (f.t === 'url' ? ' inputmode="url" placeholder="https://"' : '') + '>';
        return '<div class="field"' + span + '><label for="' + id + '">' + esc(f.l) + (f.req ? ' *' : '') + '</label>' + ctl + '<span class="field-error"></span></div>';
      }).join('') + '</div><div class="edit-actions"><button type="button" class="btn btn-outline" data-cancel>Cancel</button><button type="submit" class="btn btn-primary">Save changes</button></div></form>';
    }

    function card(m, sec, own) {
      if (sec.priv && !own) return '';
      var isEdit = own && editing === sec.id;
      return '<section class="card p-card" id="' + sec.id + '"><div class="p-card-head"><div><h2>' + esc(sec.title) + '</h2>' + (sec.sub ? '<p>' + esc(sec.sub) + '</p>' : '') + '</div>' +
        (own && !isEdit ? '<button type="button" class="btn btn-outline btn-sm" data-edit="' + sec.id + '">Edit</button>' : '') + '</div>' +
        (isEdit ? formFor(m, sec) : infoGrid(m, sec.fields, own)) + '</section>';
    }

    function membershipCard(m, own) {
      var items = [['Member ID', L.profile.memberIdLabel(m)], ['Official role', m.role], ['Member category', m.category],
        ['Verification', m.verified ? 'Verified by LSU administrators' : 'Not verified'], ['Account status', m.status === 'pending' ? 'Registered — awaiting review' : 'Active']];
      return '<section class="card p-card" id="membership"><div class="p-card-head"><div><h2>Membership</h2><p>Managed by LSU administrators.</p></div></div><dl class="info">' +
        items.map(function (i) { return '<div class="info-item"><dt>' + i[0] + ' <span class="lock">Admin controlled</span></dt><dd>' + esc(i[1]) + '</dd></div>'; }).join('') + '</dl>' +
        (own && !m.verified ? '<div class="notice-box">' + (m.verifyRequest && m.verifyRequest.status === 'pending'
          ? 'Your verification request was sent on ' + esc(L.fmtDate(m.verifyRequest.at.slice(0, 10))) + '. An LSU administrator will review it.'
          : 'Your account is <strong>Unverified</strong>. Registration alone does not verify a member — an LSU administrator must approve it. You can send a verification request below.') + '</div>' : '') +
        '</section>';
    }

    function render() {
      if (L.auth.isReady && !L.auth.isReady()) { loadingView(); return; }
      var me = L.auth.current();
      if (!me) { gateView(); return; }
      var m = viewId ? L.members.find(viewId) : me;
      if (!m) { notFoundView(); return; }
      var own = m.id === me.id;
      document.title = m.name + ' — LSU Member Profile';
      var canAskVerify = own && !m.verified && !(m.verifyRequest && m.verifyRequest.status === 'pending');
      var navItems = [['about', 'About'], ['personal', 'Personal'], own ? ['contact', 'Contact'] : null, ['professional', 'Professional'], ['social', 'Social links'], ['education', 'Education'], ['membership', 'Membership']].filter(Boolean);
      var roleTag = m.category === 'Executive'
        ? '<span class="tag ' + (m.role === 'President' ? 'tag-gold' : '') + '">' + esc(m.role) + '</span>'
        : '<span class="tag tag-muted">' + esc(m.category || 'Member') + '</span>';
      root.innerHTML =
        '<article class="p-hero">' +
        '<div class="p-cover"></div>' +
        '<div class="p-body">' +
        '<div class="p-avatar">' +
        '<img class="avatar" id="pAvatar" src="' + esc(m.photo || L.avatar(m.name)) + '" onerror="this.onerror=null;this.src=\'' + L.avatar(m.name) + '\'" alt="Photo of ' + esc(m.name) + '" width="120" height="120">' +
        (own ? '<button type="button" class="p-photo-btn" id="photoBtn">Change photo</button><input type="file" id="photoInput" accept="image/png,image/jpeg,image/webp" hidden>' : '') +
        '</div>' +
        '<div class="p-id">' +
        '<h1>' + esc(m.name) + (m.verified ? ' ' + L.verifiedBadge() : '') + '</h1>' +
        '<p class="p-sub">' + esc([m.designation || m.profession, m.org].filter(Boolean).join(' · ') || 'LSU member') + '</p>' +
        '<div class="p-tags">' + statusPill(m) + roleTag + '</div>' +
        '</div>' +
        '<div class="p-actions">' +
        (own
          ? (canAskVerify ? '<button type="button" class="btn btn-accent" id="verifyBtn">Request verification</button>' : '') +
            (L.auth.isAdmin(me) ? '<a class="btn btn-outline" href="/admin">Admin Panel</a>' : '') +
            '<button type="button" class="btn btn-outline" data-action="logout">Sign Out</button>'
          : '<a class="btn btn-outline" href="/members">Back to Members</a>') +
        '</div></div></article>' +
        '<div class="p-stats"><div class="card p-stat"><small>Member ID</small><strong>' + esc(L.profile.memberIdLabel(m)) + '</strong></div>' +
        '<div class="card p-stat"><small>Official role</small><strong>' + esc(m.role) + '</strong></div>' +
        '<div class="card p-stat"><small>Category</small><strong>' + esc(m.category) + '</strong></div>' +
        '<div class="card p-stat"><small>SSC batch</small><strong>' + esc(m.batch || '—') + '</strong></div></div>' +
        '<div class="p-layout"><aside class="card p-nav" aria-label="Profile sections">' + navItems.map(function (n) { return '<a href="#' + n[0] + '">' + n[1] + '</a>'; }).join('') +
        (own ? '<div class="p-complete">Profile completion <strong>' + completion(m) + '%</strong><div class="bar"><i style="width:' + completion(m) + '%"></i></div></div>' : '') + '</aside>' +
        '<div class="p-stack">' + SECTIONS.map(function (s) { return card(m, s, own); }).join('') + membershipCard(m, own) + '</div></div>';
    }

    /* ---------- interactions (delegated, bound once) ---------- */
    function currentOwn() { var me = L.auth.current(); return me && (!viewId || viewId === me.id) ? me : null; }

    root.addEventListener('click', function (e) {
      var t = e.target;
      var ed = t.closest('[data-edit]');
      if (ed) { editing = ed.getAttribute('data-edit'); render(); var f = $('[data-form] input,[data-form] textarea,[data-form] select'); if (f) f.focus(); return; }
      if (t.closest('[data-cancel]')) { editing = null; render(); return; }
      if (t.closest('#photoBtn')) { $('#photoInput').click(); return; }
      if (t.closest('#verifyBtn')) {
        Promise.resolve(L.profile.requestVerification()).then(function (r) {
          if (r && r.ok) { L.toast('Verification request sent to LSU administrators.'); render(); }
          else if (r && r.error) L.toast(r.error, 'error');
        });
      }
    });

    root.addEventListener('change', function (e) {
      if (e.target.id !== 'photoInput' || !e.target.files[0]) return;
      var file = e.target.files[0];
      if (!/^image\/(png|jpeg|webp)$/.test(file.type)) { L.toast('Please choose a PNG, JPG or WebP image.', 'error'); return; }
      if (file.size > 6 * 1024 * 1024) { L.toast('Image is too large (max 6 MB).', 'error'); return; }
      var img = new Image(), url = URL.createObjectURL(file);
      img.onload = function () {
        var size = 320, c = document.createElement('canvas'); c.width = c.height = size;
        var s = Math.min(img.width, img.height), sx = (img.width - s) / 2, sy = (img.height - s) / 2;
        c.getContext('2d').drawImage(img, sx, sy, s, s, 0, 0, size, size);
        URL.revokeObjectURL(url);
        Promise.resolve(L.profile.updateOwn({ photo: c.toDataURL('image/jpeg', 0.85) })).then(function (res) {
          L.toast(res.ok ? 'Profile photo updated.' : (res.error || 'Could not save photo.'), res.ok ? '' : 'error');
          if (res.ok) render();
        });
      };
      img.onerror = function () { URL.revokeObjectURL(url); L.toast('That image could not be read.', 'error'); };
      img.src = url;
    });

    root.addEventListener('submit', function (e) {
      var form = e.target.closest('[data-form]');
      if (!form || !currentOwn()) return;
      e.preventDefault();
      var sec = SECTIONS.filter(function (s) { return s.id === form.getAttribute('data-form'); })[0];
      var patch = {}, firstBad = null, alertBox = form.querySelector('.alert');
      alertBox.classList.remove('show');
      sec.fields.forEach(function (f) {
        if (f.locked) return;
        var inp = form.elements[f.k], v = inp.value.trim(), msg = '';
        if (f.req && !v) msg = f.l.replace(' *', '') + ' is required.';
        else if (f.rule) msg = f.rule(v);
        var wrap = inp.closest('.field'); wrap.classList.toggle('has-error', !!msg);
        wrap.querySelector('.field-error').textContent = msg;
        if (msg) { inp.setAttribute('aria-invalid', 'true'); firstBad = firstBad || inp; } else inp.removeAttribute('aria-invalid');
        patch[f.k] = v;
      });
      if (firstBad) { firstBad.focus(); return; }
      Promise.resolve(L.profile.updateOwn(patch)).then(function (res) {
        if (!res.ok) { alertBox.textContent = res.error || 'Could not save changes.'; alertBox.classList.add('show'); return; }
        editing = null; render(); L.toast('Profile updated.');
      });
    });

    render();
    document.addEventListener('lsu:authchange', function () { if (!editing) render(); else if (!L.auth.current()) { editing = null; render(); } });
  }
  if (window.LSU) window.LSU.ready(start);
})();
