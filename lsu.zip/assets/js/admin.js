/* Admin panel — private. Only accounts with admin:true can access. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$, esc = L.esc;
    var root = $('#adminRoot');
    var tab = 'pending';
    var detailId = null;
    function executiveRoles() {
      var p = window.LSU_EXECUTIVE_PANEL;
      return p && p.groups ? p.groups.map(function (g) { return g.designation; }) : [];
    }
    function optionList(values, selected) {
      return values.map(function (v) { return '<option value="' + esc(v) + '"' + (v === selected ? ' selected' : '') + '>' + esc(v) + '</option>'; }).join('');
    }

    function gate() {
      document.title = 'Admin access required — LSU';
      root.innerHTML = '<section class="card admin-gate">' +
        '<img class="avatar" src="' + L.guestAvatar() + '" alt="" width="84" height="84">' +
        '<h1>Admin access required</h1>' +
        '<p>This area is restricted to LSU administrators. Sign in with an admin account to manage members and verification.</p>' +
        '<div class="gate-actions" style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap">' +
        '<a class="btn btn-primary" href="' + L.loginUrl('/admin') + '">Sign In</a>' +
        '<a class="btn btn-outline" href="/home">Back to Home</a></div></section>';
    }

    function stats(all) {
      var pending = all.filter(function (m) { return m.status === 'pending'; }).length;
      var verified = all.filter(function (m) { return m.verified; }).length;
      var verifyReq = all.filter(function (m) { return m.verifyRequest && m.verifyRequest.status === 'pending' && !m.verified; }).length;
      var active = all.filter(function (m) { return m.status === 'active'; }).length;
      return [
        [pending, 'Pending registrations'],
        [verifyReq, 'Verification requests'],
        [verified, 'Verified members'],
        [active, 'Active accounts']
      ];
    }

    function statusPill(m) {
      var s = m.status || (m.verified ? 'active' : 'pending');
      return '<span class="status-pill status-' + esc(s) + '">' + esc(s) + '</span>';
    }

    function rowActions(m) {
      var btns = [];
      if (m.status === 'pending') {
        btns.push('<button type="button" class="btn btn-primary btn-sm" data-act="approve" data-id="' + esc(m.id) + '">Approve</button>');
        btns.push('<button type="button" class="btn btn-outline btn-sm" data-act="reject" data-id="' + esc(m.id) + '">Reject</button>');
      }
      if (!m.verified) {
        btns.push('<button type="button" class="btn btn-accent btn-sm" data-act="verify" data-id="' + esc(m.id) + '">Verify</button>');
      } else {
        btns.push('<button type="button" class="btn btn-outline btn-sm" data-act="unverify" data-id="' + esc(m.id) + '">Unverify</button>');
      }
      btns.push('<button type="button" class="btn btn-ghost btn-sm" data-act="detail" data-id="' + esc(m.id) + '">Details</button>');
      return '<div class="admin-actions">' + btns.join('') + '</div>';
    }

    function table(list) {
      if (!list.length) return '<div class="admin-empty">No members in this list.</div>';
      return '<div class="admin-table-wrap"><table class="admin-table"><thead><tr>' +
        '<th>Member / ID</th><th>Status</th><th>Verified</th><th>Role</th><th>Actions</th></tr></thead><tbody>' +
        list.map(function (m) {
          return '<tr><td><div class="name-cell"><img src="' + (m.photo || L.avatar(m.name)) + '" alt="">' +
            '<div><strong>' + esc(m.name) + (m.verified ? ' ' + L.verifiedBadge() : '') + '</strong>' +
            '<small>' + esc(m.email || '') + ' · ' + esc(L.profile.memberIdLabel(m)) + '</small></div></div></td>' +
            '<td>' + statusPill(m) + '</td>' +
            '<td>' + (m.verified ? 'Yes' : 'No') + '</td>' +
            '<td>' + esc(m.role || 'Member') + '</td>' +
            '<td>' + rowActions(m) + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }

    function detailPanel(m) {
      if (!m) return '';
      return '<div class="admin-detail" id="adminDetail">' +
        '<div style="display:flex;align-items:center;gap:14px;margin-bottom:12px">' +
        '<img class="avatar" src="' + (m.photo || L.avatar(m.name)) + '" width="56" height="56" alt="">' +
        '<div><h2>' + esc(m.name) + (m.verified ? ' ' + L.verifiedBadge() : '') + '</h2>' +
        '<div class="meta">' + esc(L.profile.memberIdLabel(m)) + ' · ' + esc(m.email || '—') + '</div></div></div>' +
        '<dl>' +
        '<dt>Status</dt><dd>' + statusPill(m) + '</dd>' +
        '<dt>Verified</dt><dd>' + (m.verified ? 'Yes' : 'No') + '</dd>' +
        '<dt>Position / Title</dt><dd>' + esc(m.role || 'Member') + '</dd>' +
        '<dt>Category</dt><dd>' + esc(m.category || 'General Member') + '</dd>' +
        '<dt>Batch</dt><dd>' + esc(m.batch || '—') + '</dd>' +
        '<dt>Phone</dt><dd>' + esc(m.phone || '—') + '</dd>' +
        '<dt>Profession</dt><dd>' + esc(m.profession || '—') + '</dd>' +
        '<dt>Verify request</dt><dd>' + (m.verifyRequest && m.verifyRequest.status === 'pending' ? 'Pending since ' + esc(m.verifyRequest.at || '') : 'None') + '</dd>' +
        '</dl>' +
        '<div class="admin-role-editor"><label for="adminRoleInput">Executive Board role</label><div class="admin-role-row"><select class="input" id="adminRoleInput">' + optionList(['Member'].concat(executiveRoles()), m.role || 'Member') + '</select></div>' +
        '<label for="adminCategoryInput">Member category</label><div class="admin-role-row"><select class="input" id="adminCategoryInput">' + optionList(['General Member', 'Executive', 'Alumni'], m.category || 'General Member') + '</select>' +
        '<button type="button" class="btn btn-primary btn-sm" data-act="save-role" data-id="' + esc(m.id) + '">Save changes</button></div><small>Choose an Executive Board position and set category to Executive. The member appears on the board after verification.</small></div>' +
        '<div class="admin-actions" style="margin-top:18px">' +
        (!m.verified ? '<button type="button" class="btn btn-accent btn-sm" data-act="verify" data-id="' + esc(m.id) + '">Verify member</button>' :
          '<button type="button" class="btn btn-outline btn-sm" data-act="unverify" data-id="' + esc(m.id) + '">Remove verification</button>') +
        (m.status === 'pending' ? '<button type="button" class="btn btn-primary btn-sm" data-act="approve" data-id="' + esc(m.id) + '">Approve registration</button><button type="button" class="btn btn-outline btn-sm" data-act="reject" data-id="' + esc(m.id) + '">Reject</button>' : '') +
        (m.status === 'active' || !m.status ? '<button type="button" class="btn btn-outline btn-sm" data-act="suspend" data-id="' + esc(m.id) + '">Suspend</button>' : '') +
        (m.status === 'suspended' || m.status === 'rejected' ? '<button type="button" class="btn btn-primary btn-sm" data-act="activate" data-id="' + esc(m.id) + '">Reactivate</button>' : '') +
        '<button type="button" class="btn btn-ghost btn-sm" data-act="close-detail">Close</button>' +
        '</div></div>';
    }

    function render() {
      var u = L.auth.current();
      if (!u || !L.auth.isAdmin(u)) { gate(); return; }
      document.title = 'Admin Panel — LSU';
      var all = L.members.all();
      var st = stats(all);
      var list;
      if (tab === 'pending') list = all.filter(function (m) { return m.status === 'pending'; });
      else if (tab === 'verify') list = all.filter(function (m) { return m.verifyRequest && m.verifyRequest.status === 'pending' && !m.verified; });
      else if (tab === 'verified') list = all.filter(function (m) { return m.verified; });
      else list = all;

      list.sort(function (a, b) { var x = parseInt(a.memberId, 10), y = parseInt(b.memberId, 10); x = isNaN(x) ? 999999999 : x; y = isNaN(y) ? 999999999 : y; return x - y || String(a.name || '').localeCompare(String(b.name || '')); });

      var q = ($('#adminSearch') && $('#adminSearch').value || '').trim().toLowerCase();
      if (q) list = list.filter(function (m) {
        return (m.name || '').toLowerCase().indexOf(q) >= 0 ||
          (m.email || '').toLowerCase().indexOf(q) >= 0 ||
          (m.id || '').toLowerCase().indexOf(q) >= 0 ||
          (m.memberId || '').toLowerCase().indexOf(q) >= 0;
      });

      root.innerHTML =
        '<div class="admin-dash">' +
        '<div class="admin-head"><div><span class="eyebrow">Administration</span><h1>Admin Panel</h1>' +
        '<p>Signed in as ' + esc(u.name) + '. Manage registrations, verification and member records.</p></div>' +
        '<a class="btn btn-outline" href="/members">Members Directory</a></div>' +
        '<div class="admin-stats">' + st.map(function (s) {
          return '<div class="admin-stat"><strong>' + s[0] + '</strong><span>' + s[1] + '</span></div>';
        }).join('') + '</div>' +
        '<div class="admin-tabs" role="tablist">' +
        [['pending', 'Pending'], ['verify', 'Verification requests'], ['verified', 'Verified'], ['all', 'All members']].map(function (t) {
          return '<button type="button" role="tab" class="' + (tab === t[0] ? 'active' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>';
        }).join('') + '</div>' +
        '<div class="admin-toolbar"><input class="input" id="adminSearch" type="search" placeholder="Search by name, email or ID" value="' + esc(q) + '"></div>' +
        table(list) +
        (detailId ? detailPanel(L.members.find(detailId)) : '') +
        '</div>';

      bind();
    }

    function bind() {
      root.querySelectorAll('[data-tab]').forEach(function (b) {
        b.addEventListener('click', function () { tab = b.getAttribute('data-tab'); detailId = null; render(); });
      });
      var search = $('#adminSearch');
      if (search) {
        var t;
        search.addEventListener('input', function () {
          clearTimeout(t);
          t = setTimeout(function () { render(); }, 200);
        });
      }
      var roleSelect = $('#adminRoleInput');
      if (roleSelect) roleSelect.addEventListener('change', function () {
        var cat = $('#adminCategoryInput');
        if (cat && executiveRoles().indexOf(this.value) >= 0) cat.value = 'Executive';
        else if (cat && this.value === 'Member') cat.value = 'General Member';
      });
      root.querySelectorAll('[data-act]').forEach(function (b) {
        b.addEventListener('click', function () {
          var act = b.getAttribute('data-act');
          var id = b.getAttribute('data-id');
          if (act === 'close-detail') { detailId = null; render(); return; }
          if (act === 'save-role') {
            var roleInput = $('#adminRoleInput');
            var newRole = roleInput ? roleInput.value : '';
            var categoryInput = $('#adminCategoryInput');
            var newCategory = categoryInput ? categoryInput.value : 'General Member';
            b.disabled = true; b.textContent = 'Saving…';
            L.admin.setRole(id, newRole, newCategory).then(function (r) {
              if (r && r.ok) { L.toast('Position updated successfully.'); render(); }
              else { L.toast((r && r.error) || 'Could not update position.', 'error'); b.disabled = false; b.textContent = 'Save position'; }
            });
            return;
          }
          if (act === 'detail') { detailId = id; render(); return; }
          var res;
          var actionPromise = null;
          if (act === 'approve') actionPromise = L.admin.approve(id);
          else if (act === 'reject') actionPromise = L.admin.reject(id);
          else if (act === 'verify') {
            var selectedRole = $('#adminRoleInput'), selectedCategory = $('#adminCategoryInput');
            if (selectedRole && selectedCategory) {
              actionPromise = L.admin.setRole(id, selectedRole.value, selectedCategory.value).then(function (saved) {
                return saved && saved.ok ? L.admin.setVerified(id, true) : saved;
              });
            } else actionPromise = L.admin.setVerified(id, true);
          }
          else if (act === 'unverify') actionPromise = L.admin.setVerified(id, false);
          else if (act === 'suspend') actionPromise = L.admin.setStatus(id, 'suspended');
          else if (act === 'activate') actionPromise = L.admin.setStatus(id, 'active');
          if (!actionPromise) return;
          Promise.resolve(actionPromise).then(function (res) {
            if (res && res.ok) {
              L.toast(act.charAt(0).toUpperCase() + act.slice(1) + ' successful.');
              render();
            } else if (res) L.toast(res.error || 'Action failed.', 'error');
          });
        });
      });
    }

    document.addEventListener('lsu:authchange', render);
    render();
  }
  if (window.LSU && window.LSU.isReady) start();
  else document.addEventListener('lsu:ready', start, { once: true });
})();
