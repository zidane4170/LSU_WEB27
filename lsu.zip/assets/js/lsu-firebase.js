/* LSU Firebase bridge — replaces localStorage auth with Firebase Auth + Firestore.
   Load after firebase-config.js, Firebase SDKs, lsu-data.js, and BEFORE lsu-core.js is ideal,
   but this file patches window.LSU after core if needed. Preferred load order is in HTML. */

(function () {
  'use strict';
  if (window.__LSU_FB_BRIDGE__) return;
  window.__LSU_FB_BRIDGE__ = true;

  var cfg = window.LSU_FIREBASE || {};
  var fbConfig = cfg.config || {};
  var adminEmails = (cfg.adminEmails || []).map(function (e) { return String(e).toLowerCase(); });

  function isConfigured() {
    return fbConfig.apiKey && fbConfig.apiKey !== 'YOUR_API_KEY' && fbConfig.projectId && fbConfig.projectId !== 'YOUR_PROJECT_ID';
  }

  if (!isConfigured()) {
    console.warn('[LSU Firebase] Not configured — edit assets/js/firebase-config.js');
    document.addEventListener('DOMContentLoaded', function () {
      if (document.getElementById('lsuConfigBanner')) return;
      var b = document.createElement('div');
      b.id = 'lsuConfigBanner';
      b.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:9999;background:#7a1f1a;color:#fff;padding:12px 16px;font:600 14px/1.45 system-ui,sans-serif;text-align:center';
      b.innerHTML = 'Firebase not configured. Edit <code style="background:rgba(255,255,255,.2);padding:2px 6px;border-radius:4px">assets/js/firebase-config.js</code> — see FIREBASE_SETUP.md';
      document.body.appendChild(b);
      document.body.style.paddingTop = '52px';
    });
    return;
  }

  if (typeof firebase === 'undefined') {
    console.error('[LSU Firebase] SDK missing');
    return;
  }

  // Clear legacy localStorage authentication state
  try {
    ['lsu.session', 'lsuLoggedIn', 'lsuCurrentMember', 'lsu.accounts', 'lsu.memberPatches'].forEach(function (k) {
      localStorage.removeItem(k);
      sessionStorage.removeItem(k);
    });
  } catch (e) {}

  if (!firebase.apps.length) firebase.initializeApp(fbConfig);
  var auth = firebase.auth();
  var db = firebase.firestore();
  var storage = null;
  try { storage = firebase.storage(); } catch (e) {}

  var currentMember = null;
  var authReady = false;
  var authLoadError = null;
  var membersCache = [];
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function mapDoc(doc) {
    var d = doc.data() || {};
    d.id = d.id || doc.id;
    d.uid = d.uid || doc.id;
    return d;
  }

  function loadMember(uid) {
    return db.collection('members').doc(uid).get().then(function (snap) {
      if (!snap.exists) return null;
      var m = mapDoc(snap);
      return m;
    });
  }

  function refreshMembers() {
    // Pending/unverified accounts may read only their own profile. Never issue
    // a collection query for them; Firestore rules independently enforce this.
    if (!currentMember) { membersCache = []; return Promise.resolve(membersCache); }
    if (!currentMember.admin && (currentMember.verified !== true || currentMember.status !== 'active')) {
      membersCache = [currentMember];
      return Promise.resolve(membersCache);
    }
    var query = currentMember.admin
      ? db.collection('members')
      : db.collection('members').where('verified', '==', true).where('status', '==', 'active');
    return query.get().then(function (snap) {
      membersCache = [];
      snap.forEach(function (doc) { membersCache.push(mapDoc(doc)); });
      return membersCache;
    }).catch(function (err) {
      console.warn('[LSU] Could not refresh member directory:', err);
      membersCache = currentMember.admin ? [] : [currentMember];
      return membersCache;
    });
  }

  function authError(code) {
    var map = {
      'auth/invalid-email': 'Enter a valid email address.',
      'auth/user-disabled': 'This account has been disabled.',
      'auth/user-not-found': 'Incorrect email or password.',
      'auth/wrong-password': 'Incorrect email or password.',
      'auth/invalid-credential': 'Incorrect email or password.',
      'auth/email-already-in-use': 'An account with this email already exists.',
      'auth/weak-password': 'Password is too weak.',
      'auth/too-many-requests': 'Too many attempts. Try again later.',
      'auth/network-request-failed': 'Network error. Check your connection.',
      'auth/operation-not-allowed': 'Enable Email/Password in Firebase Console → Authentication.'
    };
    return map[code] || 'Something went wrong. Please try again.';
  }

  function applyApi(L) {
    if (!L) return;

    L.members.all = function () { return membersCache.slice(); };
    L.members.find = function (id) {
      for (var i = 0; i < membersCache.length; i++) {
        var m = membersCache[i];
        if (m.id === id || m.uid === id || m.memberId === id) return m;
      }
      return null;
    };
    L.members.refresh = refreshMembers;

    L.auth.current = function () { return currentMember; };
    L.auth.isReady = function () { return authReady; };
    L.auth.loadError = function () { return authLoadError; };
    L.auth.isAdmin = function (u) { return !!(u && u.admin === true); };

    L.auth.login = function (identifier, password, remember) {
      var id = String(identifier || '').trim();
      var persist = remember === false
        ? firebase.auth.Auth.Persistence.SESSION
        : firebase.auth.Auth.Persistence.LOCAL;

      return auth.setPersistence(persist).then(function () {
        if (id.indexOf('@') === -1) {
          return db.collection('members').where('memberId', '==', id).limit(1).get().then(function (snap) {
            if (snap.empty) return Promise.reject({ code: 'auth/user-not-found' });
            var email = snap.docs[0].data().email;
            if (!email) return Promise.reject({ code: 'auth/user-not-found' });
            return auth.signInWithEmailAndPassword(email, password);
          });
        }
        return auth.signInWithEmailAndPassword(id.toLowerCase(), password);
      }).then(function (cred) {
        var uid = cred.user.uid;
        var authEmail = String(cred.user.email || '').toLowerCase();
        return loadMember(uid).then(function (m) {
          // Auto-heal: Auth exists but Firestore profile missing
          if (!m) {
            var isAdm = adminEmails.indexOf(authEmail) >= 0;
            var member = {
              uid: uid, id: uid, memberId: isAdm ? 'LSU-ADMIN-001' : '',
              name: (cred.user.displayName || authEmail.split('@')[0] || 'Member'),
              email: authEmail, phone: '', batch: '', gender: '',
              role: 'Member', category: 'General Member',
              verified: false, status: 'active', admin: false,
              photo: '', bio: '', profession: '', org: '', designation: '',
              createdAt: firebase.firestore.FieldValue.serverTimestamp()
            };
            return db.collection('members').doc(uid).set(member).then(function () {
              if (isAdm) return db.collection('members').doc(uid).update({ admin: true, adminRole: 'main', status: 'active' });
            }).then(function () {
              member.admin = isAdm;
              currentMember = member;
              return refreshMembers().then(function () {
                document.dispatchEvent(new CustomEvent('lsu:authchange'));
                return { ok: true, user: member };
              });
            });
          }
          if (m.status === 'rejected' || m.status === 'suspended') {
            return { ok: false, error: 'This account is not active. Please contact LSU.' };
          }
          var email = String(m.email || authEmail).toLowerCase();
          if (adminEmails.indexOf(email) >= 0 && !m.admin) {
            return db.collection('members').doc(m.uid).update({ admin: true, adminRole: 'main', status: 'active' }).then(function () {
              m.admin = true; m.adminRole = 'main'; m.status = 'active';
              currentMember = m;
              return refreshMembers().then(function () {
                document.dispatchEvent(new CustomEvent('lsu:authchange'));
                return { ok: true, user: m };
              });
            });
          }
          currentMember = m;
          return refreshMembers().then(function () {
            document.dispatchEvent(new CustomEvent('lsu:authchange'));
            return { ok: true, user: m };
          });
        });
      }).catch(function (err) {
        return { ok: false, error: authError(err.code) || (err.message || 'Sign in failed.') };
      });
    };

    L.auth.register = function (d) {
      var email = String(d.email || '').trim().toLowerCase();
      var name = String(d.name || '').trim();
      if (!EMAIL_RE.test(email)) return Promise.resolve({ ok: false, field: 'email', error: 'Enter a valid email address.' });
      if (!name) return Promise.resolve({ ok: false, field: 'name', error: 'Enter your full name.' });
      if (!L.auth.strongPassword(d.password)) return Promise.resolve({ ok: false, field: 'password', error: 'Use at least 8 characters with a letter and a number.' });
      var isAdminEmail = adminEmails.indexOf(email) >= 0;

      return auth.createUserWithEmailAndPassword(email, d.password).then(function (cred) {
        var uid = cred.user.uid;
        // Always create admin:false (Firestore rules). Login promotes adminEmails.
        var member = {
          uid: uid, id: uid, memberId: '', name: name, email: email,
          phone: String(d.phone || '').trim(), batch: String(d.batch || '').trim(), gender: d.gender || '',
          role: 'Member', category: 'General Member', verified: false,
          status: isAdminEmail ? 'active' : 'pending', admin: false,
          createdAt: firebase.firestore.FieldValue.serverTimestamp(),
          photo: '', bio: '', profession: '', org: '', designation: ''
        };
        return db.collection('members').doc(uid).set(member).then(function () {
          currentMember = member;
          return refreshMembers().then(function () {
            document.dispatchEvent(new CustomEvent('lsu:authchange'));
            return { ok: true, user: member };
          });
        });
      }).catch(function (err) {
        return { ok: false, field: err.code === 'auth/email-already-in-use' ? 'email' : null, error: authError(err.code) };
      });
    };

    L.auth.logout = function (redirect) {
      return auth.signOut().then(function () {
        currentMember = null;
        document.dispatchEvent(new CustomEvent('lsu:authchange'));
        if (redirect) window.location.href = redirect;
      });
    };

    L.auth.requestPasswordReset = function (email) {
      var e = String(email || '').trim().toLowerCase();
      if (!EMAIL_RE.test(e)) return Promise.resolve({ ok: false, error: 'Enter a valid email address.' });
      return auth.sendPasswordResetEmail(e).then(function () {
        return { ok: true, message: 'If an account exists for that email, a password reset link has been sent.' };
      }).catch(function (err) {
        if (err.code === 'auth/user-not-found') {
          return { ok: true, message: 'If an account exists for that email, a password reset link has been sent.' };
        }
        return { ok: false, error: authError(err.code) };
      });
    };

    L.auth.changePassword = function (currentPass, newPass) {
      var user = auth.currentUser;
      if (!user || !user.email) return Promise.resolve({ ok: false, error: 'Not signed in.' });
      if (!L.auth.strongPassword(newPass)) return Promise.resolve({ ok: false, error: 'New password must be at least 8 characters with a letter and a number.' });
      var cred = firebase.auth.EmailAuthProvider.credential(user.email, currentPass);
      return user.reauthenticateWithCredential(cred).then(function () {
        return user.updatePassword(newPass);
      }).then(function () { return { ok: true }; })
        .catch(function (err) {
          if (err.code === 'auth/wrong-password' || err.code === 'auth/invalid-credential') {
            return { ok: false, error: 'Current password is incorrect.' };
          }
          return { ok: false, error: authError(err.code) };
        });
    };

    var OWN = ['name', 'gender', 'dob', 'location', 'phone', 'address', 'bio', 'profession', 'org', 'designation', 'skills', 'interests',
      'facebook', 'linkedin', 'website', 'batch', 'sscInstitution', 'hscInstitution', 'hsc', 'university', 'subject', 'bachelor', 'master', 'photo'];

    L.profile.updateOwn = function (patch) {
      var u = currentMember;
      if (!u || !auth.currentUser) return Promise.resolve({ ok: false, error: 'Not signed in.' });
      var clean = {};
      OWN.forEach(function (k) { if (Object.prototype.hasOwnProperty.call(patch, k)) clean[k] = patch[k]; });
      if (clean.name !== undefined && !String(clean.name).trim()) return Promise.resolve({ ok: false, error: 'Name cannot be empty.' });
      clean.updatedAt = firebase.firestore.FieldValue.serverTimestamp();
      return db.collection('members').doc(u.uid).update(clean).then(function () {
        return loadMember(u.uid).then(function (m) {
          currentMember = m;
          return refreshMembers().then(function () {
            document.dispatchEvent(new CustomEvent('lsu:authchange'));
            return { ok: true, user: m };
          });
        });
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not save.' }; });
    };

    L.profile.requestVerification = function () {
      var u = currentMember;
      if (!u || u.verified) return Promise.resolve({ ok: false });
      var req = { status: 'pending', at: new Date().toISOString() };
      return db.collection('members').doc(u.uid).update({ verifyRequest: req }).then(function () {
        return loadMember(u.uid).then(function (m) {
          currentMember = m;
          document.dispatchEvent(new CustomEvent('lsu:authchange'));
          return { ok: true, user: m };
        });
      });
    };

    function requireAdmin() {
      return currentMember && currentMember.admin ? currentMember : null;
    }

    L.admin.setVerified = function (id, verified) {
      if (!requireAdmin()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var m = L.members.find(id);
      if (!m) return Promise.resolve({ ok: false, error: 'Member not found.' });
      var memberRef = db.collection('members').doc(m.uid || m.id);
      if (!verified) {
        return memberRef.update({ verified: false }).then(function () {
          return refreshMembers().then(function () { document.dispatchEvent(new CustomEvent('lsu:authchange')); return { ok: true, user: L.members.find(id) }; });
        }).catch(function (err) { return { ok: false, error: err.message || 'Could not update verification.' }; });
      }
      var counterRef = db.collection('meta').doc('memberSerial');
      var cachedMax = membersCache.reduce(function (max, item) { var n = parseInt(item.memberId, 10); return isFinite(n) && n > max ? n : max; }, 1000);
      return db.runTransaction(function (tx) {
        return tx.get(memberRef).then(function (memberSnap) {
          if (!memberSnap.exists) throw new Error('Member not found.');
          var data = memberSnap.data() || {};
          var existing = String(data.memberId || '');
          if (/^\d+$/.test(existing)) {
            tx.update(memberRef, { verified: true, status: 'active', verifyRequest: firebase.firestore.FieldValue.delete() });
            return existing;
          }
          return tx.get(counterRef).then(function (counterSnap) {
            var last = counterSnap.exists ? Number(counterSnap.data().lastIssued || 1000) : 1000;
            if (!isFinite(last) || last < 1000) last = 1000;
            last = Math.max(Math.floor(last), cachedMax);
            var next = last + 1;
            tx.set(counterRef, { lastIssued: next }, { merge: true });
            tx.update(memberRef, { memberId: String(next), verified: true, status: 'active', verifyRequest: firebase.firestore.FieldValue.delete() });
            return String(next);
          });
        });
      }).then(function () {
        return refreshMembers().then(function () { document.dispatchEvent(new CustomEvent('lsu:authchange')); return { ok: true, user: L.members.find(id) }; });
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not verify member.' }; });
    };

    L.admin.setRole = function (id, role, category) {
      if (!requireAdmin()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var m = L.members.find(id);
      var cleanRole = String(role || '').trim().replace(/\s+/g, ' ');
      if (!m) return Promise.resolve({ ok: false, error: 'Member not found.' });
      if (!cleanRole || cleanRole.length > 80) return Promise.resolve({ ok: false, error: 'Enter a position between 1 and 80 characters.' });
      var cleanCategory = String(category || m.category || 'General Member').trim();
      if (['General Member', 'Executive', 'Alumni'].indexOf(cleanCategory) < 0) return Promise.resolve({ ok: false, error: 'Invalid member category.' });
      return db.collection('members').doc(m.uid || m.id).update({ role: cleanRole, category: cleanCategory }).then(function () {
        return refreshMembers().then(function () {
          if (currentMember && (currentMember.uid === m.uid || currentMember.id === m.id)) { currentMember.role = cleanRole; currentMember.category = cleanCategory; }
          document.dispatchEvent(new CustomEvent('lsu:authchange'));
          return { ok: true, user: L.members.find(id) };
        });
      }).catch(function (err) { return { ok: false, error: err.message || 'Could not update position.' }; });
    };

    L.admin.setStatus = function (id, status) {
      if (!requireAdmin()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var m = L.members.find(id);
      if (!m) return Promise.resolve({ ok: false, error: 'Member not found.' });
      return db.collection('members').doc(m.uid || m.id).update({ status: status }).then(function () {
        return refreshMembers().then(function () {
          document.dispatchEvent(new CustomEvent('lsu:authchange'));
          return { ok: true, user: L.members.find(id) };
        });
      }).catch(function (err) { return { ok: false, error: err.message }; });
    };

    L.admin.approve = function (id) {
      if (!requireAdmin()) return Promise.resolve({ ok: false, error: 'Admin access required.' });
      var m = L.members.find(id);
      if (!m) return Promise.resolve({ ok: false, error: 'Member not found.' });
      var patch = { status: 'active' };
      return db.collection('members').doc(m.uid || m.id).update(patch).then(function () {
        return refreshMembers().then(function () {
          document.dispatchEvent(new CustomEvent('lsu:authchange'));
          return { ok: true, user: L.members.find(id) };
        });
      }).catch(function (err) { return { ok: false, error: err.message }; });
    };

    L.admin.reject = function (id) { return L.admin.setStatus(id, 'rejected'); };


    L.firebaseConfigured = function () { return true; };
  }

  function startAuthListener() {
    auth.onAuthStateChanged(function (user) {
      authReady = false;
      authLoadError = null;
      if (!user) {
        currentMember = null;
        authReady = true;
        document.dispatchEvent(new CustomEvent('lsu:authchange'));
        return;
      }
      var uid = user.uid;
      var email = String(user.email || '').trim().toLowerCase();
      var isBootstrapAdmin = adminEmails.indexOf(email) !== -1;
      loadMember(uid).then(function (member) {
        // Restore older Firebase Auth accounts that do not yet have a Firestore profile.
        if (!member) {
          member = {
            uid: uid, id: uid, memberId: isBootstrapAdmin ? 'LSU-ADMIN-001' : '',
            name: user.displayName || (email ? email.split('@')[0] : 'LSU Member'),
            email: email, phone: '', batch: '', gender: '', role: 'Member',
            category: 'General Member', verified: false,
            status: isBootstrapAdmin ? 'active' : 'pending', admin: false,
            photo: user.photoURL || '', bio: '', profession: '', org: '', designation: '',
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
          };
          return db.collection('members').doc(uid).set(member).then(function () { return member; });
        }
        return member;
      }).then(function (member) {
        if (!member) throw new Error('Your member profile could not be loaded.');
        if (member.status === 'rejected' || member.status === 'suspended') {
          currentMember = null;
          authLoadError = 'This account is not active. Please contact LSU.';
          return null;
        }
        // Only the configured bootstrap email can self-promote; Firestore Rules enforce it too.
        if (isBootstrapAdmin && member.admin !== true) {
          return db.collection('members').doc(uid).update({ admin: true, adminRole: 'main', status: 'active' }).then(function () {
            member.admin = true; member.adminRole = 'main'; member.status = 'active'; return member;
          });
        }
        return member;
      }).then(function (member) {
        currentMember = member || null;
        return refreshMembers();
      }).then(function () {
        authReady = true;
        document.dispatchEvent(new CustomEvent('lsu:authchange'));
      }).catch(function (err) {
        currentMember = null;
        authLoadError = err && err.code === 'permission-denied'
          ? 'Your account is signed in, but Firestore access is blocked. Publish the current Firestore Rules and try again.'
          : 'We could not load your LSU profile. Please refresh the page or contact an administrator.';
        authReady = true;
        console.error('[LSU Firebase] Could not restore signed-in profile:', err);
        document.dispatchEvent(new CustomEvent('lsu:authchange'));
      });
    });
  }

  function boot() {
    function go() {
      if (!window.LSU) return false;
      applyApi(window.LSU);
      startAuthListener();
      // refresh members for board when possible
      refreshMembers().then(function () {
        document.dispatchEvent(new CustomEvent('lsu:authchange'));
      });
      return true;
    }
    if (!go()) {
      document.addEventListener('lsu:ready', function () { go(); }, { once: true });
    }
  }

  boot();
})();
