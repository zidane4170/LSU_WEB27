/* Registration page. Anyone may register; accounts always start Unverified / Pending. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$;
    var slot = $('#authSlot');
    var thisYear = new Date().getFullYear();

    function formView() {
      slot.innerHTML =
        '<img class="avatar avatar-lg" src="' + L.guestAvatar() + '" alt="" width="76" height="76">' +
        '<h2 id="regTitle">Create an account</h2>' +
        '<p class="sub">New accounts are Unverified until an administrator reviews them.</p>' +
        '<form class="form" id="regForm" novalidate>' +
        '<div class="alert alert-error" id="formAlert" role="alert"></div>' +
        '<div class="field" id="fName"><label for="name">Full name</label><input class="input" id="name" name="name" type="text" autocomplete="name" maxlength="80" placeholder="Your full name"><span class="field-error" id="eName"></span></div>' +
        '<div class="field" id="fEmail"><label for="email">Email</label><input class="input" id="email" name="email" type="email" autocomplete="email" autocapitalize="none" spellcheck="false" placeholder="you@example.com"><span class="field-error" id="eEmail"></span></div>' +
        '<div class="field" id="fPhone"><label for="phone">Mobile number <span class="opt">(optional)</span></label><input class="input" id="phone" name="phone" type="tel" autocomplete="tel" placeholder="+880 1XXX-XXXXXX"><span class="field-error" id="ePhone"></span></div>' +
        '<div class="field" id="fBatch"><label for="batch">SSC passing year (batch)</label><input class="input" id="batch" name="batch" type="text" inputmode="numeric" maxlength="4" placeholder="e.g. 2022"><span class="field-error" id="eBatch"></span></div>' +
        '<div class="field" id="fGender"><label for="gender">Gender <span class="opt">(optional)</span></label><select class="input" id="gender" name="gender"><option value="">Prefer not to say</option><option>Female</option><option>Male</option><option>Other</option></select></div>' +
        '<div class="field" id="fPw"><label for="password">Password</label><div class="input-wrap"><input class="input" id="password" name="password" type="password" autocomplete="new-password" placeholder="At least 8 characters"><button type="button" class="input-toggle" id="pwToggle" aria-label="Show password" aria-pressed="false">' + L.icon('eye') + '</button></div><span class="field-error" id="ePw"></span></div>' +
        '<div class="field" id="fPw2"><label for="password2">Confirm password</label><input class="input" id="password2" name="password2" type="password" autocomplete="new-password" placeholder="Re-enter password"><span class="field-error" id="ePw2"></span></div>' +
        '<label class="check"><input type="checkbox" id="remember" checked> Keep me signed in after registering</label>' +
        '<button class="btn btn-primary btn-block" id="submitBtn" type="submit">Create account</button>' +
        '</form>' +
        '<p class="auth-foot">Already have an account? <a class="text-link" href="/login">Sign In</a></p>';
      bindForm();
    }

    function setErr(fieldId, errId, msg) {
      var f = $('#' + fieldId); if (!f) return !msg;
      var inp = f.querySelector('input, select');
      f.classList.toggle('has-error', !!msg);
      var e = $('#' + errId); if (e) e.textContent = msg || '';
      if (inp) { if (msg) inp.setAttribute('aria-invalid', 'true'); else inp.removeAttribute('aria-invalid'); }
      return !msg;
    }

    function validate() {
      var name = $('#name').value.trim();
      var email = $('#email').value.trim();
      var phone = $('#phone').value.trim();
      var batch = $('#batch').value.trim();
      var pw = $('#password').value;
      var pw2 = $('#password2').value;
      var ok = true;
      ok = setErr('fName', 'eName', !name ? 'Enter your full name.' : (name.length < 2 ? 'Name is too short.' : '')) && ok;
      ok = setErr('fEmail', 'eEmail', !email ? 'Enter your email.' : (!L.auth.isEmail(email) ? 'Enter a valid email address.' : '')) && ok;
      ok = setErr('fPhone', 'ePhone', phone && !/^[+\d][\d\s-]{6,18}$/.test(phone) ? 'Enter a valid phone number.' : '') && ok;
      ok = setErr('fBatch', 'eBatch', !batch ? 'Enter your SSC passing year.' : (!/^\d{4}$/.test(batch) || +batch < 1950 || +batch > thisYear + 6 ? 'Enter a valid 4-digit year.' : '')) && ok;
      ok = setErr('fPw', 'ePw', !pw ? 'Enter a password.' : (!L.auth.strongPassword(pw) ? 'Use at least 8 characters with a letter and a number.' : '')) && ok;
      ok = setErr('fPw2', 'ePw2', pw2 !== pw ? 'Passwords do not match.' : '') && ok;
      return ok;
    }

    function bindForm() {
      var form = $('#regForm'), alertBox = $('#formAlert'), btn = $('#submitBtn');
      $('#pwToggle').addEventListener('click', function (e) {
        var pw = $('#password'), show = pw.type === 'password';
        pw.type = show ? 'text' : 'password';
        e.currentTarget.innerHTML = L.icon(show ? 'eye-off' : 'eye');
        e.currentTarget.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
        e.currentTarget.setAttribute('aria-pressed', String(show));
      });
      ['name', 'email', 'phone', 'batch', 'password', 'password2'].forEach(function (id) {
        var el = $('#' + id); if (el) el.addEventListener('input', function () { alertBox.classList.remove('show'); });
      });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        alertBox.classList.remove('show');
        if (!validate()) return;
        btn.disabled = true; btn.textContent = 'Creating account…';
        L.auth.register({
          name: $('#name').value.trim(),
          email: $('#email').value.trim(),
          phone: $('#phone').value.trim(),
          batch: $('#batch').value.trim(),
          gender: $('#gender').value,
          password: $('#password').value,
          remember: $('#remember').checked,
          signIn: true
        }).then(function (res) {
          if (!res.ok) {
            btn.disabled = false; btn.textContent = 'Create account';
            if (res.field === 'email') setErr('fEmail', 'eEmail', res.error);
            else { alertBox.textContent = res.error || 'Could not create account.'; alertBox.classList.add('show'); }
            return;
          }
          L.toast('Account created. You are signed in as an Unverified member.', 'ok');
          window.location.href = '/profile';
        }).catch(function () {
          btn.disabled = false; btn.textContent = 'Create account';
          alertBox.textContent = 'Something went wrong. Please try again.';
          alertBox.classList.add('show');
        });
      });
    }

    formView();
  }
  if (window.LSU && window.LSU.isReady) start();
  else document.addEventListener('lsu:ready', start, { once: true });
})();
