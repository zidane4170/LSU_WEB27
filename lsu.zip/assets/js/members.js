/* Members Directory — requires sign-in. No redirect loop. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$, esc = L.esc;
    var root = $('#membersRoot');
    var filter = { q: '', cat: '' };

    function gate() {
      document.title = 'Sign in to view members — LSU';
      root.innerHTML = '<section class="card members-gate">' +
        '<img class="avatar" src="' + L.guestAvatar() + '" alt="" width="84" height="84">' +
        '<h1>Members Directory</h1>' +
        '<p>The member directory is available to signed-in members. Sign in to browse profiles, or create a free account to join LSU.</p>' +
        '<div class="gate-actions">' +
        '<a class="btn btn-primary" href="' + L.loginUrl('/members') + '">Sign In</a>' +
        '<a class="btn btn-outline" href="/register">Register</a></div></section>';
    }

    function card(m) {
      return '<article class="card member-card">' +
        '<div class="top"><img src="' + (m.photo || L.avatar(m.name)) + '" alt="" width="56" height="56">' +
        '<div><h3>' + esc(m.name) + (m.verified ? ' ' + L.verifiedBadge() : '') + '</h3>' +
        '<div class="meta">' + esc(L.profile.memberIdLabel(m)) + ' · ' + esc(m.role || 'Member') + (m.batch ? ' · Batch ' + esc(m.batch) : '') + '</div></div></div>' +
        '<div class="tags">' +
        '<span class="tag">' + esc(m.category || 'General Member') + '</span>' +
        (m.verified ? '<span class="tag">Verified</span>' : '<span class="tag tag-muted">Unverified</span>') +
        '</div>' +
        (m.profession ? '<p class="meta">' + esc(m.profession) + (m.org ? ' · ' + esc(m.org) : '') + '</p>' : '') +
        '<a class="link-arrow" href="/profile?id=' + encodeURIComponent(m.id) + '">View profile ' + L.icon('arrow') + '</a></article>';
    }

    function render() {
      if (L.auth.isReady && !L.auth.isReady()) { root.innerHTML = '<section class="card members-gate"><div class="loading-spinner" aria-hidden="true"></div><p>Loading your LSU access…</p></section>'; return; }
      var u = L.auth.current();
      if (!u) { gate(); return; }
      if (!u.admin && (u.verified !== true || u.status !== 'active')) {
        document.title = 'Verification pending — LSU';
        root.innerHTML = '<section class="card members-gate"><h1>Verification pending</h1>' +
          '<p>Your account is waiting for Admin approval. Until your account is verified, the Members Directory, other member profiles and member photos are unavailable.</p>' +
          '<p>You can access your own account details and sign out. Please check back after approval.</p></section>';
        return;
      }
      document.title = 'Members Directory — LSU';
      var all = L.members.all().filter(function (m) {
        return m.verified === true && m.status === 'active';
      });
      var list = all.filter(function (m) {
        if (filter.cat && !((filter.cat === 'General' && ['General','General Member'].indexOf(m.category || '') >= 0) || (m.category || '') === filter.cat)) return false;
        if (filter.q) {
          var q = filter.q.toLowerCase();
          var hay = [m.name, m.email, m.role, m.batch, m.profession, m.org, m.id, m.memberId].join(' ').toLowerCase();
          if (hay.indexOf(q) < 0) return false;
        }
        return true;
      });
      list.sort(function (a, b) {
        var x = parseInt(a.memberId, 10), y = parseInt(b.memberId, 10);
        x = isNaN(x) ? Number.MAX_SAFE_INTEGER : x;
        y = isNaN(y) ? Number.MAX_SAFE_INTEGER : y;
        return x - y || String(a.name || '').localeCompare(String(b.name || ''));
      });

      root.innerHTML =
        '<div class="members-head"><div><span class="eyebrow">Community</span><h1>Members Directory</h1>' +
        '<p>Browse verified members of Lalmohan Students’ Union.</p></div>' +
        (L.auth.isAdmin(u) ? '<a class="btn btn-outline" href="/admin">Admin Panel</a>' : '') +
        '</div>' +
        '<div class="members-toolbar">' +
        '<input class="input" id="mSearch" type="search" placeholder="Search by name, batch, role…" value="' + esc(filter.q) + '">' +
        '<select class="input" id="mCat"><option value="">All categories</option><option value="Executive"' + (filter.cat === 'Executive' ? ' selected' : '') + '>Executive</option><option value="General"' + (filter.cat === 'General' ? ' selected' : '') + '>General</option><option value="Alumni"' + (filter.cat === 'Alumni' ? ' selected' : '') + '>Alumni</option></select>' +
        '</div>' +
        '<div class="members-count">' + list.length + ' member' + (list.length === 1 ? '' : 's') + '</div>' +
        '<div class="members-grid">' + (list.length ? list.map(card).join('') : '<div class="members-empty">No members match your filters.</div>') + '</div>';

      var t;
      $('#mSearch').addEventListener('input', function () {
        clearTimeout(t);
        var v = this.value;
        t = setTimeout(function () { filter.q = v; render(); }, 180);
      });
      $('#mCat').addEventListener('change', function () { filter.cat = this.value; render(); });
    }

    document.addEventListener('lsu:authchange', render);
    render();
  }
  if (window.LSU && window.LSU.isReady) start();
  else document.addEventListener('lsu:ready', start, { once: true });
})();
