/* LSU seed data — events, notices, and offline board fallback.
   Live members come from Firebase Firestore when configured. */
(function () {
  'use strict';
  if (window.LSU_DATA) return;

  var MEMBERS = [];

  var EVENTS = [];

  var NOTICES = [];

  var PROGRAMS = [];

  window.LSU_DATA = { MEMBERS: MEMBERS, EVENTS: EVENTS, NOTICES: NOTICES, PROGRAMS: PROGRAMS };
})();
