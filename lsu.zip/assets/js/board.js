/* Verified Executive Board — visible only to signed-in members. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, root = L.$('#boardFull');
    if (!root) return;
    var panel = window.LSU_EXECUTIVE_PANEL || { groups: [], tagline: '' };
    var roles = (panel.groups || []).map(function (g) { return g.designation; });
    function initials(name) {
      return String(name || '').replace(/\s*\([^)]*\)\s*/g, ' ').trim().split(/\s+/).slice(0, 2)
        .map(function (p) { return p.charAt(0); }).join('').toUpperCase() || 'LSU';
    }
    function gate() {
      root.innerHTML = '<section class="card members-gate"><img class="avatar" src="' + L.guestAvatar() + '" alt="" width="84" height="84">' +
        '<h2>Sign in to view the Executive Board</h2><p>Executive profiles, photos and member details are available to signed-in LSU members only.</p>' +
        '<div class="gate-actions"><a class="btn btn-primary" href="' + L.loginUrl('/executive') + '">Sign In</a>' +
        '<a class="btn btn-outline" href="/register">Register</a></div></section>';
    }
    function render() {
      if (L.auth.isReady && !L.auth.isReady()) { root.innerHTML = '<section class="card members-gate"><div class="loading-spinner" aria-hidden="true"></div><p>Loading your LSU access…</p></section>'; return; }
      var u = L.auth.current();
      if (!u) { gate(); return; }
      if (!u.admin && (u.verified !== true || u.status !== 'active')) {
        root.innerHTML = '<section class="card members-gate"><h2>Verification pending</h2><p>The Executive Board and its member profiles will be available after your account is verified by an Admin.</p></section>';
        return;
      }
      var execs = L.members.all().filter(function (m) {
        return m.verified === true && m.category === 'Executive' && m.status !== 'suspended' && m.status !== 'rejected';
      });
      execs.sort(function (a, b) {
        var ai = roles.indexOf(a.role || ''), bi = roles.indexOf(b.role || '');
        ai = ai < 0 ? 9999 : ai; bi = bi < 0 ? 9999 : bi;
        var idA = parseInt(a.memberId, 10), idB = parseInt(b.memberId, 10);
        return ai - bi || ((isNaN(idA) ? 999999999 : idA) - (isNaN(idB) ? 999999999 : idB)) || String(a.name || '').localeCompare(String(b.name || ''));
      });
      var groups = roles.map(function (role) {
        return { designation: role, members: execs.filter(function (m) { return m.role === role; }) };
      }).filter(function (g) { return g.members.length; });
      var unlisted = execs.filter(function (m) { return roles.indexOf(m.role || '') < 0; });
      if (unlisted.length) groups.push({ designation: 'Other Executive Roles', members: unlisted });
      var total = execs.length;
      root.innerHTML = '<div class="board-intro"><span class="board-kicker">LALMOHAN STUDENTS’ UNION</span>' +
        '<h2>Executive Board</h2><p class="board-tagline">' + L.esc(panel.tagline || '') + '</p>' +
        '<div class="board-summary"><span><strong>' + total + '</strong> Verified Executive Members</span>' +
        '<span><strong>' + groups.length + '</strong> Active Positions</span></div></div>' +
        (groups.length ? groups.map(function (group, index) {
          return '<section class="board-section" aria-labelledby="board-group-' + index + '"><div class="board-section-head">' +
            '<span class="board-index">' + String(index + 1).padStart(2, '0') + '</span><h3 id="board-group-' + index + '">' + L.esc(group.designation) + '</h3>' +
            '<span class="board-count">' + group.members.length + (group.members.length === 1 ? ' member' : ' members') + '</span></div>' +
            '<div class="board-member-grid">' + group.members.map(function (m) {
              return '<article class="card board-card"><a class="board-profile-link" href="/profile?id=' + encodeURIComponent(m.id) + '" aria-label="View ' + L.esc(m.name) + ' profile">' +
                (m.photo ? '<img class="board-avatar" src="' + L.esc(m.photo) + '" alt="' + L.esc(m.name) + '">' : '<div class="board-avatar" aria-hidden="true">' + L.esc(initials(m.name)) + '</div>') +
                '<h4>' + L.esc(m.name) + ' ' + L.verifiedBadge() + '</h4></a><span class="board-role">' + L.esc(m.role || 'Executive') + '</span>' +
                '<div class="board-member-meta">' + L.esc(L.profile.memberIdLabel(m)) + (m.batch ? ' · Batch ' + L.esc(m.batch) : '') + '</div>' +
                (m.profession ? '<p class="board-member-meta">' + L.esc(m.profession) + (m.org ? ' · ' + L.esc(m.org) : '') + '</p>' : '') +
                '<a class="link-arrow" href="/profile?id=' + encodeURIComponent(m.id) + '">View profile ' + L.icon('arrow') + '</a></article>';
            }).join('') + '</div></section>';
        }).join('') : '<div class="card admin-empty">No verified Executive Board members are assigned yet.</div>');
    }
    document.addEventListener('lsu:authchange', render);
    L.ready(function () { render(); if (L.members.refresh) L.members.refresh().then(render); });
  }
  if (window.LSU) window.LSU.ready(start);
  else window.addEventListener('load', function () { if (window.LSU) window.LSU.ready(start); });
})();
