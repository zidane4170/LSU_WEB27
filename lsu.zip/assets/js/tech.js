/* Technology & Development — LSU technology team */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$, esc = L.esc;
    var subject = encodeURIComponent('From LSU website — Technology & Development');
    var TEAM = [
      { name: 'Abdullah Al Rafi', role: 'Administrator', email: 'abdullahalrafi1007@gmail.com', linkedin: 'https://www.linkedin.com/in/thisisabdullahalrafi/', photo: 'assets/team/team-photo.png' },
      { name: 'Rayhan Tamim', role: 'Deputy Administrator', email: 'official.rayhantamim@gmail.com', linkedin: 'https://www.linkedin.com/in/rayhan-tamim-851b843b3?trk=my-connections_member-image', photo: 'https://media.licdn.com/dms/image/v2/D4D03AQGOdy65n0Jexw/profile-displayphoto-scale_400_400/B4DaGPzh2zHkAg-/0/1793414014174?e=2147483647&v=beta&t=xNYyrZ3OyOr3wUriZJj6LoOfR0I_06UbdkUUiEFaK94' },
      { name: 'Omar Faruk', role: 'Data Analyst', email: 'official.omarfaruk@gmail.com', linkedin: 'https://www.linkedin.com/in/omar-faruk-a964b9444?trk=my-connections_member-image', photo: 'https://media.licdn.com/dms/image/v2/D4D03AQGTk0csJk2UQg/profile-displayphoto-scale_400_400/B4DaFIni82I0Ag-/0/1792219691233?e=2147483647&v=beta&t=OdkEjjwDBGYXiAuGwn-nK18PeEe2-AnKUy-cUkfx3L8' }
    ];
    $('#techGrid').innerHTML = TEAM.map(function (person) {
      var contact = '<a class="tech-action tech-mail" href="mailto:' + esc(person.email) + '?subject=' + subject + '">' + L.icon('mail') + '<span>Contact</span></a>';
      var linkedin = '<a class="tech-action tech-in" href="' + esc(person.linkedin) + '" target="_blank" rel="noopener noreferrer">' + L.icon('linkedin') + '<span>LinkedIn</span></a>';
      return '<article class="tech-card"><div class="tech-ring"><img src="' + esc(person.photo || L.avatar(person.name)) + '" alt="Photo of ' + esc(person.name) + '" width="112" height="112" loading="lazy" referrerpolicy="no-referrer"></div><h3>' + esc(person.name) + '</h3><p class="tech-role">' + esc(person.role) + '</p><div class="tech-actions">' + contact + linkedin + '</div></article>';
    }).join('');
    Array.prototype.forEach.call($('#techGrid').querySelectorAll('img'), function (img, index) {
      img.addEventListener('error', function () { img.src = L.avatar(TEAM[index].name); }, { once: true });
    });
  }
  if (window.LSU && window.LSU.isReady) start(); else document.addEventListener('lsu:ready', start, { once: true });
})();
