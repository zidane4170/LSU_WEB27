/**
 * LSU — Firebase configuration (filled for project: lsu-test)
 */
window.LSU_FIREBASE = {
  config: {
    apiKey: "AIzaSyDlpRKsEVJ0lfnX7Uil_q1622bCbJy8RYM",
    authDomain: "lsu-test.firebaseapp.com",
    projectId: "lsu-test",
    storageBucket: "lsu-test.firebasestorage.app",
    messagingSenderId: "445403323807",
    appId: "1:445403323807:web:e86757f9d2103a44bcf1aa"
  },

  /* Initial Main Admin. Add additional authorised administrators here only after provisioning them securely. */
  adminEmails: [
    "abdullahalrafi1007@gmail.com"
  ],
  mainAdminEmails: [
    "abdullahalrafi1007@gmail.com"
  ],
  mediaAdminEmails: [],

  site: {
    name: "Lalmohan Students’ Union",
    short: "LSU",
    est: 2007,
    motto: "Unity · Education · Progress",
    location: "Lalmohan, Bhola, Bangladesh"
  }
};
