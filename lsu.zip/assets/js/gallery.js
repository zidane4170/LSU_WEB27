(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$, esc = L.esc;
    // Public Google Drive share links can be pasted by a media administrator.
    // This normalizes /file/d/FILE_ID/view and open?id=FILE_ID to a direct image endpoint.
    function driveImageUrl(value) {
      var raw = String(value || '').trim();
      var id = (raw.match(/\/file\/d\/([a-zA-Z0-9_-]+)/) || [])[1];
      if (!id) { try { id = new URL(raw).searchParams.get('id'); } catch (e) {} }
      return id ? 'https://drive.google.com/uc?export=view&id=' + encodeURIComponent(id) : raw;
    }
    window.LSU_DRIVE_IMAGE_URL = driveImageUrl;
    var items = [
      { src: 'assets/gallery-campus.svg', caption: 'Campus' },
      { src: 'assets/gallery-workshop.svg', caption: 'Workshop' },
      { src: 'assets/gallery-volunteer.svg', caption: 'Volunteer day' },
      { src: 'assets/gallery-tech.svg', caption: 'Technology' },
      { src: 'assets/gallery-team.svg', caption: 'Team' },
      { src: 'assets/event-leadership.svg', caption: 'Leadership forum' },
      { src: 'assets/event-education.svg', caption: 'Education workshop' },
      { src: 'assets/event-community.svg', caption: 'Community service' }
    ];
    $('#galleryGrid').innerHTML = items.map(function (g) {
      return '<figure class="gallery-item"><img src="' + esc(g.src) + '" alt="' + esc(g.caption) + '"><figcaption>' + esc(g.caption) + '</figcaption></figure>';
    }).join('');
  }
  if (window.LSU && window.LSU.isReady) start();
  else document.addEventListener('lsu:ready', start, { once: true });
})();
