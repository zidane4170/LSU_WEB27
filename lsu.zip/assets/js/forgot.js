/* Firebase password reset flow. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, $ = L.$;
    var slot = $('#authSlot');
    var params = new URLSearchParams(window.location.search);
    var token = params.get('token');

    function requestView() {
      slot.innerHTML =
        '<h2 id="fpTitle">Forgot password</h2>' +
        '<p class="sub">We will send a secure password reset link to your email.</p>' +
        '<form class="form" id="fpForm" novalidate>' +
        '<div class="alert alert-error" id="formAlert" role="alert"></div>' +
        '<div class="alert alert-ok" id="formOk" role="status"></div>' +
        '<div class="field" id="fEmail"><label for="email">Email</label><input class="input" id="email" type="email" autocomplete="email" autocapitalize="none" placeholder="you@example.com"><span class="field-error" id="eEmail"></span></div>' +
        '<button class="btn btn-primary btn-block" id="submitBtn" type="submit">Continue</button>' +
        '</form>' +
        '<p class="auth-foot"><a class="text-link" href="/login">Back to Sign In</a></p>';
      var form = $('#fpForm'), alertBox = $('#formAlert'), okBox = $('#formOk'), btn = $('#submitBtn');
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        alertBox.classList.remove('show'); okBox.classList.remove('show');
        var email = $('#email').value.trim();
        if (!email || !L.auth.isEmail(email)) {
          $('#fEmail').classList.add('has-error');
          $('#eEmail').textContent = 'Enter a valid email address.';
          return;
        }
        $('#fEmail').classList.remove('has-error'); $('#eEmail').textContent = '';
        btn.disabled = true; btn.textContent = 'Please wait…';
        Promise.resolve(L.auth.requestPasswordReset(email)).then(function (res) {
          btn.disabled = false; btn.textContent = 'Continue';
          if (!res.ok) {
            alertBox.textContent = res.error; alertBox.classList.add('show');
            return;
          }
          okBox.textContent = res.message || 'Check your email for a password reset link.';
          okBox.classList.add('show');
        }).catch(function () {
          btn.disabled = false; btn.textContent = 'Continue';
          alertBox.textContent = 'Something went wrong. Please try again.';
          alertBox.classList.add('show');
        });
      });
    }

    function resetView() {
      slot.innerHTML =
        '<h2 id="fpTitle">Set a new password</h2>' +
        '<p class="sub">Choose a strong password for your account.</p>' +
        '<form class="form" id="resetForm" novalidate>' +
        '<div class="alert alert-error" id="formAlert" role="alert"></div>' +
        '<div class="field" id="fPw"><label for="password">New password</label><div class="input-wrap"><input class="input" id="password" type="password" autocomplete="new-password" placeholder="At least 8 characters"><button type="button" class="input-toggle" id="pwToggle" aria-label="Show password">' + L.icon('eye') + '</button></div><span class="field-error" id="ePw"></span></div>' +
        '<div class="field" id="fPw2"><label for="password2">Confirm password</label><input class="input" id="password2" type="password" autocomplete="new-password"><span class="field-error" id="ePw2"></span></div>' +
        '<button class="btn btn-primary btn-block" id="submitBtn" type="submit">Update password</button>' +
        '</form>' +
        '<p class="auth-foot"><a class="text-link" href="/login">Back to Sign In</a></p>';
      $('#pwToggle').addEventListener('click', function (e) {
        var pw = $('#password'), show = pw.type === 'password';
        pw.type = show ? 'text' : 'password';
        e.currentTarget.innerHTML = L.icon(show ? 'eye-off' : 'eye');
      });
      $('#resetForm').addEventListener('submit', function (e) {
        e.preventDefault();
        var alertBox = $('#formAlert'), btn = $('#submitBtn');
        alertBox.classList.remove('show');
        var pw = $('#password').value, pw2 = $('#password2').value;
        var ok = true;
        if (!L.auth.strongPassword(pw)) {
          $('#fPw').classList.add('has-error'); $('#ePw').textContent = 'Use at least 8 characters with a letter and a number.';
          ok = false;
        } else { $('#fPw').classList.remove('has-error'); $('#ePw').textContent = ''; }
        if (pw !== pw2) {
          $('#fPw2').classList.add('has-error'); $('#ePw2').textContent = 'Passwords do not match.';
          ok = false;
        } else { $('#fPw2').classList.remove('has-error'); $('#ePw2').textContent = ''; }
        if (!ok) return;
        btn.disabled = true; btn.textContent = 'Updating…';
        L.auth.completePasswordReset(token, pw).then(function (res) {
          if (!res.ok) {
            btn.disabled = false; btn.textContent = 'Update password';
            alertBox.textContent = res.error; alertBox.classList.add('show');
            return;
          }
          window.location.href = '/login?reset=1';
        });
      });
    }

    if (token) resetView(); else requestView();
  }
  if (window.LSU && window.LSU.isReady) start();
  else document.addEventListener('lsu:ready', start, { once: true });
})();
