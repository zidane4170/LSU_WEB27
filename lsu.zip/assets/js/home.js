/* Home page behaviour. Public page: never redirects, never requires sign-in. */
(function () {
  'use strict';
  function start() {
    var L = window.LSU, el = L.$;

    function arrow() { return L.icon('arrow'); }

    function renderHero() {
      var u = L.auth.current();
      el('#heroCta').innerHTML = u
        ? '<a class="btn btn-accent" href="/members">Open Members Directory ' + arrow() + '</a>' +
          '<a class="btn btn-line-light" href="/profile">My Profile</a>' +
          '<a class="btn btn-line-light" href="/executive">Executive Board</a>'
        : '<a class="btn btn-accent" href="/register">Become a Member ' + arrow() + '</a>' +
          '<a class="btn btn-line-light" href="/login">Sign In</a>' +
          '<a class="btn btn-line-light" href="/executive">Executive Board</a>';
    }

    function renderStats() {
      var all = L.members.all();
      var verified = all.filter(function (m) { return m.verified; }).length;
      var upcoming = L.data.EVENTS.filter(function (e) { return !L.isPast(e.date); }).length;
      var items = [
        ['calendar', L.config.est, 'Established'],
        ['shield', verified, 'Verified members'],
        ['board', upcoming, 'Upcoming events']
      ];
      el('#stats').innerHTML = items.map(function (s) {
        return '<div class="stat"><span class="stat-icon">' + L.icon(s[0]) + '</span><div><strong>' + L.esc(s[1]) + '</strong><span>' + s[2] + '</span></div></div>';
      }).join('');
    }

    function renderBoard() {
      var president = L.members.all().filter(function (m) {
        return m.verified === true && m.status === 'active' && m.role === 'President';
      })[0];
      if (!president) {
        el('#boardGrid').innerHTML = '<p class="empty-note">The verified President profile will appear here.</p>';
        return;
      }
      var initials = String(president.name || 'LSU').split(/\s+/).slice(0, 2).map(function (p) { return p.charAt(0); }).join('').toUpperCase();
      el('#boardGrid').innerHTML =
        '<article class="card leader leader-president"><a href="/profile?id=' + encodeURIComponent(president.id) + '">' +
        (president.photo ? '<img class="leader-avatar" src="' + L.esc(president.photo) + '" alt="' + L.esc(president.name) + '">' : '<div class="leader-avatar" aria-hidden="true">' + L.esc(initials) + '</div>') +
        '<span class="leader-eyebrow">PRESIDENT</span><h3>' + L.esc(president.name) + '</h3></a>' +
        '<span class="tag tag-gold">President, LSU</span></article>';
    }

    function renderEvents() {
      var up = L.data.EVENTS.filter(function (e) { return !L.isPast(e.date); })
        .sort(function (a, b) { return a.date < b.date ? -1 : 1; }).slice(0, 3);
      el('#eventList').innerHTML = up.length ? up.map(function (e) {
        var d = new Date(e.date + 'T00:00:00');
        return '<article class="event"><div class="event-date" aria-hidden="true"><b>' + String(d.getDate()).padStart(2, '0') + '</b><small>' +
          d.toLocaleDateString('en-GB', { month: 'short' }).toUpperCase() + '</small></div><div><h3>' + L.esc(e.title) + '</h3><p>' +
          L.fmtDate(e.date, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' }) + ' · ' + L.esc(e.time) + '<br>' + L.esc(e.venue) + '</p></div></article>';
      }).join('') : '<p class="empty-note">No upcoming events right now. Please check back soon.</p>';
    }

    function renderCta() {
      var u = L.auth.current();
      el('#ctaBand').innerHTML = u
        ? '<div><h2>Welcome back, ' + L.esc(String(u.name).split(' ')[0]) + '</h2><p>' + (u.verified ? 'Your membership is verified by LSU.' : 'Your account is awaiting verification by an LSU administrator.') + '</p></div>' +
          '<div class="cta-actions"><a class="btn btn-light" href="/members">Members Directory</a><a class="btn btn-line-light" href="/profile">My Profile</a></div>'
        : '<div><h2>Join the LSU community</h2><p>Anyone can register. New accounts start as Unverified — an LSU administrator reviews and verifies members.</p></div>' +
          '<div class="cta-actions"><a class="btn btn-light" href="/register">Register</a><a class="btn btn-line-light" href="/login">Sign In</a></div>';
    }

    function renderAll() { renderHero(); renderStats(); renderBoard(); renderEvents(); renderCta(); }
    renderAll();
    document.addEventListener('lsu:authchange', renderAll);
  }
  if (window.LSU) window.LSU.ready(start);
  else window.addEventListener('load', function () { if (window.LSU) window.LSU.ready(start); });
})();
