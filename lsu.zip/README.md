# Lalmohan Students’ Union (LSU) — Professional Website

Firebase Auth + Firestore powered site for Lalmohan Students’ Union (est. 2007).

## Deploy
1. Unzip and upload the folder to Netlify (root = where `index.html` is).
2. Firebase is already configured for project `lsu-test`.
3. Ensure Authentication → Email/Password is enabled.
4. Publish the included `firestore.rules` and `storage.rules` in Firebase Console. The updated Firestore Rules are required for the Admin bootstrap and role/verification controls.
5. Add your Netlify domain under Authentication → Authorized domains.

## Admin
The existing account `support.eyms@gmail.com` is configured as the initial administrator. After publishing the included Firestore Rules, sign in with that existing account; it will be promoted to Admin on the next successful login. No new account is required.

The Admin Panel supports registration approval/rejection, verification/unverification, account suspension/reactivation, and assigning a member position/title. These actions are enforced by Firestore Rules, not only by the interface.

## Pages
Home, About (structure + how we work), Programs, Executive Board, Members, Profile,
Events, Notices, Gallery, Contact, Technology, Login, Register, Forgot Password, Admin.

## Official links
- Facebook: https://www.facebook.com/lalmohanstudentsunion/
- LinkedIn: https://www.linkedin.com/company/lalmohan-students-union

## Latest UI / UX polish
- Added Inter font (Google Fonts) for consistent, professional typography across all pages.
- Normalized font-weights to standard values (400/500/600/700/800).
- Improved mobile spacing, hero layout, stats grid, and section padding.
- Refined button shadows, hover states, and touch-friendly sizes.
- Cleaned unused legacy `assets/styles.css` (smaller deploy package).
- Consistent container margins and card gaps on small screens.
- Better mobile profile, contact, gallery and technology card layouts.


## Official Executive Panel update
See `EXECUTIVE_PANEL_IMPLEMENTATION_REPORT.md`. The official public roster is maintained in `assets/js/executive-panel.js`.


## Admin verification and Executive Board updates

- When an administrator verifies a member, the system assigns the next numeric Member ID (starting at 1001) using a Firestore transaction and a counter document at `meta/memberSerial`. Existing numeric IDs are retained; old non-numeric IDs are replaced the next time that member is verified.
- The Admin Panel lets administrators select an official Executive Board designation from a dropdown and change the member category. Set the category to `Executive`; selecting an official Board role also switches the category to Executive automatically.
- The Executive Board page displays only verified, active Executive-category member records, in the official designation order (President first). Cards show the member's uploaded profile photo when available and link to the full profile.
- Member Directory is sorted by numeric Member ID ascending. Profiles, member directory and Executive Board require sign-in.
- **Deployment required:** publish the included `firestore.rules` in Firebase Console → Firestore Database → Rules. Without deploying these rules, the sign-in-only profile visibility requirement is not enforced by Firestore.

## Pending-account privacy and access control (added)
- Accounts with `verified !== true` or `status !== 'active'` are restricted to their own profile while signed in.
- Pending accounts cannot query or browse the member directory, Executive Board, other member profiles, or profile photos.
- Firestore rules enforce this server-side; the client also avoids directory queries and displays a verification-pending notice.
- Active verified members can view the member directory and Executive Board while signed in. Admins retain full access.
- Publish both `firestore.rules` and `storage.rules` in the Firebase Console for these restrictions to take effect. Client-side UI restrictions alone are not a security boundary.
