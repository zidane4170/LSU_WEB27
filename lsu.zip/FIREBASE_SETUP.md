# LSU Website — Firebase Setup (বাংলা + English)

এই ফোল্ডারটি **Firebase Auth + Firestore** দিয়ে চালানোর জন্য প্রস্তুত।  
Config দিলে এবং rules deploy করলেই Login, Register, Members, Admin, Verification কাজ করবে।

---

## ১) Firebase প্রজেক্ট তৈরি

1. যান: [https://console.firebase.google.com](https://console.firebase.google.com)
2. **Add project** → নাম দিন (যেমন `lsu-portal`)
3. Google Analytics optional — Skip করা যায়

### Web App যোগ করুন
1. Project Overview → **</> Web**
2. App nickname: `LSU Website`
3. **Firebase Hosting** টিক না দিলেও চলবে (Netlify ব্যবহার করলে)
4. Config object কপি করুন — দেখতে এরকম:

```js
const firebaseConfig = {
  apiKey: "...",
  authDomain: "...",
  projectId: "...",
  storageBucket: "...",
  messagingSenderId: "...",
  appId: "..."
};
```

---

## ২) Config ফাইলে পেস্ট করুন

ফাইল খুলুন: **`assets/js/firebase-config.js`**

`YOUR_API_KEY`, `YOUR_PROJECT_ID` ইত্যাদি আপনার config দিয়ে বদলান।

### Admin ইমেইল
একই ফাইলে `adminEmails` তালিকায় অনুমোদিত Admin ইমেইল রাখতে হবে। এই প্যাকেজে `support.eyms@gmail.com` আগে থেকেই সেট করা আছে। এই ইমেইলের বিদ্যমান Firebase account দিয়ে পরবর্তী Login করলেই Firestore profile-এ Admin access সক্রিয় হবে; নতুন account তৈরি করতে হবে না।

---

## ৩) Authentication চালু করুন

Firebase Console → **Authentication** → **Get started**  
→ **Sign-in method** → **Email/Password** → **Enable** → Save

(Optional) Password reset ইমেইল টেমপ্লেট: Authentication → Templates

---

## ৪) Firestore Database

1. **Build → Firestore Database → Create database**
2. **Start in production mode**
3. Location: `asia-south1` (বা কাছের region)
4. **Rules** ট্যাব → `firestore.rules` ফাইলের পুরো কনটেন্ট পেস্ট → **Publish**

---

## ৫) Storage (প্রোফাইল ছবি)

1. **Build → Storage → Get started**
2. Production mode
3. **Rules** → `storage.rules` ফাইলের কনটেন্ট পেস্ট → **Publish**

---

## ৬) Authorized domains (গুরুত্বপূর্ণ)

Authentication → **Settings** → **Authorized domains**

যোগ করুন:
- `localhost`
- আপনার Netlify domain — যেমন `yoursite.netlify.app`
- কাস্টম ডোমেইন থাকলে সেটাও

---

## ৭) Deploy (Netlify)

1. এই পুরো ফোল্ডার ZIP আনজিপ করুন
2. `firebase-config.js` এ config দিন
3. Netlify → **Add new site → Deploy manually** → ফোল্ডার ড্র্যাগ করুন  
   অথবা GitHub থেকে connect করুন
4. Publish directory = সাইটের root (`index.html` যেখানে)

Deploy এর পর:
1. `support.eyms@gmail.com`-এর বিদ্যমান account দিয়ে **Login** করুন (নতুন করে Register করবেন না)
2. প্রথম Login-এ Firestore Rules অনুমতি দিলে account-টি Admin হিসেবে promote হবে
3. Login-এর পর **Admin Panel** খুলুন
4. অন্যরা Register করলে **Pending** থাকবে → Admin Approve / Verify করবে

---

## কাজ করে কী কী

| Feature | Backend |
|--------|---------|
| Register | Firebase Auth + Firestore member doc |
| Login (email / Member ID) | Firebase Auth |
| Keep me signed in | Auth persistence LOCAL/SESSION |
| Logout | Auth signOut |
| Forgot password | Firebase reset email |
| Profile edit | Firestore update (own fields only) |
| Photo | Storage (fallback: Firestore) |
| Members directory | Firestore (signed-in) |
| Executive Board | Public read (category == Executive) |
| Admin verify / approve | Firestore admin-only updates |
| Verified badge | `verified: true` field |

---

## নিরাপত্তা নোট

- `apiKey` ওয়েবসাইটে public — এটা স্বাভাবিক। সুরক্ষা **Firestore/Storage Rules** দিয়ে হয়।
- Rules ছাড়া deploy করবেন না।
- Admin access কেবল `adminEmails`-এ নির্দিষ্ট bootstrap email-এর জন্য Rules-নিয়ন্ত্রিত promotion অথবা বিদ্যমান Admin-এর মাধ্যমে দেওয়া যাবে। ওয়েবসাইটের JavaScript-এ শুধু email যোগ করলেই যথেষ্ট নয়—নতুন Firestore Rules অবশ্যই Publish করতে হবে।

---

## সমস্যা সমাধান

**লাল ব্যানার: Firebase not configured**  
→ `firebase-config.js` এ এখনও `YOUR_API_KEY` আছে।

**operation-not-allowed**  
→ Authentication এ Email/Password enable করেননি।

**Missing or insufficient permissions**  
→ Firestore rules publish করেননি, বা Authorized domain নেই।

**Login হয় কিন্তু Admin Panel না**  
→ `support.eyms@gmail.com` দিয়ে Login করুন এবং এই প্যাকেজের নতুন `firestore.rules` Publish হয়েছে কিনা নিশ্চিত করুন।

---

## ফাইল তালিকা (Firebase)

- `assets/js/firebase-config.js` — আপনার config
- `assets/js/lsu-firebase.js` — Auth + Firestore bridge
- `firestore.rules` — database rules
- `storage.rules` — photo rules
- `FIREBASE_SETUP.md` — এই গাইড
